# LANBridge dedicated Windows 10/11 backup host: elevated configuration assistant.
# Scopes its firewall rule to Private + LocalSubnet; does not enable SMB1, guest or RDP.
$ErrorActionPreference = 'Stop'
$admin = [Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $admin.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this PowerShell script AS ADMINISTRATOR on the storage computer.'
}
$exe = @(
    (Join-Path $PSScriptRoot 'LANBridge-CLI.exe'),
    (Join-Path $PSScriptRoot 'LANBridge-CLI\LANBridge-CLI.exe'),
    (Join-Path $PSScriptRoot 'dist\LANBridge-CLI\LANBridge-CLI.exe')
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if ($exe -and (Test-Path -LiteralPath $exe)) {
    $runner = $exe
    $prefix = @()
} else {
    $runner = 'py.exe'
    $prefix = @('-3', (Join-Path $PSScriptRoot 'src\lanbridge.py'))
    if (-not (Get-Command py.exe -ErrorAction SilentlyContinue)) {
        throw 'Python 3 not installed. Use a Windows executable build or install Python 3.10+.'
    }
    & py.exe -3 -c 'import cryptography' 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Run: py -3 -m pip install -r requirements.txt' }
}

Write-Host 'LANBridge protected backup host setup' -ForegroundColor Cyan
Write-Host 'Run this on the Windows 10 storage computer, not the Windows 11 client.'
Write-Host 'Use a dedicated backup directory. Never use the root of your system drive.'
$folder = (Read-Host 'Storage directory (example D:\LANBridgeBackups)').Trim()
if (-not $folder) { throw 'A storage directory is required.' }
$directory = [IO.Path]::GetFullPath($folder)
if ([IO.Path]::GetPathRoot($directory).TrimEnd('\') -eq $directory.TrimEnd('\')) {
    throw 'Refusing to share the root of a drive. Create a dedicated folder.'
}
if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
    $decision = Read-Host "Create $directory now? Type YES"
    if ($decision -cne 'YES') { throw 'Cancelled.' }
    New-Item -ItemType Directory -Force -Path $directory | Out-Null
}
Write-Host "Storage folder: $directory"
Write-Host 'The Windows service runs as LocalService rather than LocalSystem.'
$permission = Read-Host 'Grant LocalService Modify access on ONLY this folder and its contents? Type YES'
if ($permission -cne 'YES') { throw 'Cannot install service without access to its data folder.' }
& icacls.exe $directory /grant '*S-1-5-19:(OI)(CI)M' | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'Unable to grant LocalService access to storage directory.' }

Write-Host 'Configuring protected-backup mode. Existing backups cannot be overwritten through LANBridge.' -ForegroundColor Cyan
& $runner @prefix configure --dir $directory --mode backup
if ($LASTEXITCODE -ne 0) { throw 'Host configuration failed. Existing config may already exist; inspect before changing it.' }

& $runner @prefix service install
if ($LASTEXITCODE -ne 0) { throw 'Windows service installation failed.' }

$fw = 'LANBridge Private LAN TCP 8537'
if (-not (Get-NetFirewallRule -DisplayName $fw -ErrorAction SilentlyContinue)) {
    Write-Host 'Firewall proposal: TCP 8537 inbound, PRIVATE profile, LocalSubnet addresses only.'
    $answer = Read-Host 'Add this inbound firewall rule? Type YES'
    if ($answer -ceq 'YES') {
        New-NetFirewallRule -DisplayName $fw -Direction Inbound -Action Allow -Protocol TCP `
            -LocalPort 8537 -Profile Private -RemoteAddress LocalSubnet | Out-Null
    }
}

& $runner @prefix service start
if ($LASTEXITCODE -ne 0) { Write-Warning 'Could not start service. Inspect: sc.exe query LANBridgeStorage' }
else { Write-Host 'Storage host configured and started.' -ForegroundColor Green }
Write-Host 'For the client, record the SHA-256 fingerprint and secret access key printed during configure.'
Write-Host 'Later: use LANBridge service stop/start/status, or Windows Services (services.msc).'
