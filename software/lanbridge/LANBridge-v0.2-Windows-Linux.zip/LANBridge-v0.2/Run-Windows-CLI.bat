@echo off
cd /d "%~dp0"
if exist "LANBridge-CLI.exe" (
    "LANBridge-CLI.exe" %*
    exit /b %errorlevel%
)
if exist "LANBridge-CLI\LANBridge-CLI.exe" (
    "LANBridge-CLI\LANBridge-CLI.exe" %*
    exit /b %errorlevel%
)
if exist "dist\LANBridge-CLI\LANBridge-CLI.exe" (
    "dist\LANBridge-CLI\LANBridge-CLI.exe" %*
    exit /b %errorlevel%
)
where py >nul 2>&1 || (echo Python 3.10+ needed. & exit /b 1)
py -3 src\lanbridge.py %*
