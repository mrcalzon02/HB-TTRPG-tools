@echo off
cd /d "%~dp0"
echo LANBridge dedicated backup-host setup (requires Administrator).
echo Right-click this file and select Run as administrator to proceed.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-Windows-BackupHost.ps1"
if errorlevel 1 pause
