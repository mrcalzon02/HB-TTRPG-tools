# LANBridge Windows Quick SMB Assistant
# Native Windows 10/11 PowerShell 5.1. No third-party dependencies.
# Intended ONLY for trusted private LANs. Never enables SMB1 or guest access.
$ErrorActionPreference = 'Stop'

function Get-HostIPv4 {
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
        Select-Object InterfaceAlias, IPAddress
}
function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Create-Share {
    Write-Host "`nThis action runs on the PC with the free storage." -ForegroundColor Cyan
    if (-not (Test-IsAdministrator)) {
        Write-Warning 'Reopen PowerShell as Administrator to create an SMB share.'
        return
    }
    $folder = Read-Host 'Full folder path to share (example D:\SharedStorage)'
    if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
        Write-Warning 'Folder does not exist. No action taken.'
        return
    }
    $name = Read-Host 'New share name (example Storage)'
    if ($name -notmatch '^[A-Za-z0-9_-]{1,32}$') {
        Write-Warning 'Only 1-32 letters, digits, - and _ are allowed.'
        return
    }
    $user = (& whoami.exe).Trim()
    Write-Host "User being granted SMB access: $user"
    Write-Host "Folder to expose: $folder"
    $answer = Read-Host 'Create SMB encrypted share with CHANGE access for this user? (type YES)'
    if ($answer -cne 'YES') { Write-Host 'Cancelled.'; return }
    New-SmbShare -Name $name -Path (Resolve-Path -LiteralPath $folder).Path -ChangeAccess $user -EncryptData $true -Confirm:$false | Out-Null
    Write-Host "Created share. Other computers can use \\$env:COMPUTERNAME\$name" -ForegroundColor Green
    Write-Host 'Windows NTFS folder permissions still apply. Port TCP 445 must be reachable.'
}
function Map-Share {
    Write-Host "`nThis action runs on the PC that needs more storage." -ForegroundColor Cyan
    $hostName = Read-Host 'Storage machine IPv4 address (example 192.168.1.50)'
    if ($hostName -notmatch '^[0-9]{1,3}(\.[0-9]{1,3}){3}$') {
        Write-Warning 'Enter a numeric IPv4 address.'; return
    }
    $share = Read-Host 'Windows SMB share name (example Storage)'
    if ($share -notmatch '^[A-Za-z0-9_$-]{1,80}$') {
        Write-Warning 'Invalid share name.'; return
    }
    $letter = (Read-Host 'Drive letter (example Z)').Trim().ToUpperInvariant()
    if ($letter -notmatch '^[A-Z]$') { Write-Warning 'Enter just one drive letter.'; return }
    $remote = "\\$hostName\$share"
    $account = Read-Host 'Windows username (example OLDPC\username), or leave empty for signed-in credentials'
    $argsList = @('use', "${letter}:", $remote)
    if ($account) { $argsList += "/user:$account"; $argsList += '*' }
    $argsList += '/persistent:yes'
    Write-Host "Mapping ${letter}: to $remote" -ForegroundColor Cyan
    & net.exe @argsList
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Mapped successfully. Open ${letter}: in File Explorer." -ForegroundColor Green
    } else {
        Write-Warning "Mapping failed with Windows error code $LASTEXITCODE. Check account password, TCP 445, Private network profile and share permissions."
    }
}
function Check-Connectivity {
    $targetIP = Read-Host 'Remote storage machine IPv4 address'
    Write-Host 'Checking SMB TCP 445. This does NOT require network discovery.'
    Test-NetConnection -ComputerName $targetIP -Port 445 -InformationLevel Detailed
}
function Allow-PrivateLanSMB {
    if (-not (Test-IsAdministrator)) {
        Write-Warning 'Reopen as Administrator to configure this scoped firewall rule.'; return
    }
    Write-Host 'Network profile:'
    Get-NetConnectionProfile | Format-Table InterfaceAlias, NetworkCategory
    Write-Host 'This allows inbound SMB TCP 445 ONLY from local subnets on PRIVATE profiles.'
    $answer = Read-Host 'Add this rule? (type YES)'
    if ($answer -cne 'YES') { return }
    $ruleName = 'LANBridge SMB LocalSubnet Private'
    $existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
    if ($existing) { Write-Host 'Rule already exists.'; return }
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow `
        -Protocol TCP -LocalPort 445 -Profile Private -RemoteAddress LocalSubnet | Out-Null
    Write-Host 'Scoped SMB firewall rule created.' -ForegroundColor Green
}

Write-Host "`nLANBridge - Windows Quick SMB Assistant" -ForegroundColor Cyan
Write-Host 'No SMB1. No guest mode. No disabling the firewall.'
Write-Host 'Local IPv4 addresses:'
Get-HostIPv4 | Format-Table -AutoSize
while ($true) {
    Write-Host "`n1) Create native SMB storage share (run on storage PC, Admin)"
    Write-Host '2) Map remote SMB share as a drive (run on client PC)'
    Write-Host '3) Test IP connectivity to SMB port 445'
    Write-Host '4) Add optional Private LAN / LocalSubnet-only SMB firewall rule (Admin)'
    Write-Host 'Q) Quit'
    $choice = (Read-Host 'Choice').Trim().ToUpperInvariant()
    try {
        switch ($choice) {
            '1' { Create-Share }
            '2' { Map-Share }
            '3' { Check-Connectivity }
            '4' { Allow-PrivateLanSMB }
            'Q' { exit 0 }
            default { Write-Host 'Choose 1, 2, 3, 4, or Q.' }
        }
    } catch {
        Write-Warning $_.Exception.Message
    }
}
