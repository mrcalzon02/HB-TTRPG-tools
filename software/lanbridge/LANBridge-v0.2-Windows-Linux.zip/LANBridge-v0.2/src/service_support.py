"""LANBridge background service helpers: systemd --user and native Windows SCM.

No third-party service manager or browser runtime required. The Windows process
implements the Service Control Manager protocol with ctypes.
"""
from __future__ import annotations

import ctypes
import os
from pathlib import Path
import shlex
import subprocess
import sys
import threading

SERVICE_NAME = 'LANBridgeStorage'
UNIT_NAME = 'lanbridge-storage.service'


def command_to_run(config):
    """Use frozen executable if installed, otherwise current Python interpreter."""
    if getattr(sys, 'frozen', False):
        return [str(Path(sys.executable).resolve()), 'service', 'run', '--config', str(Path(config).resolve())]
    return [str(Path(sys.executable).resolve()), str((Path(__file__).parent / 'lanbridge.py').resolve()),
            'service', 'run', '--config', str(Path(config).resolve())]


def systemd_unit(config):
    parts = command_to_run(config)
    # Quote each token for systemd's ExecStart lexer (not a shell).
    def quoted(s):
        return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('%', '%%') + '"'
    return ('[Unit]\nDescription=LANBridge encrypted LAN backup/storage host\n'
            'After=network-online.target\nWants=network-online.target\n\n'
            '[Service]\nType=simple\nExecStart=' + ' '.join(quoted(p) for p in parts) + '\n'
            'Restart=on-failure\nRestartSec=5\nNoNewPrivileges=true\n'
            'UMask=0077\n\n'
            '[Install]\nWantedBy=default.target\n')


def run_command(args, check=True):
    p = subprocess.run(args, capture_output=True, text=True)
    if check and p.returncode:
        raise RuntimeError((p.stderr or p.stdout or f'{args[0]} failed ({p.returncode})').strip())
    return (p.stdout + p.stderr).strip()


def manage_linux(action, config):
    if action == 'install':
        unit_dir = Path.home() / '.config' / 'systemd' / 'user'
        unit_dir.mkdir(parents=True, exist_ok=True)
        unit = unit_dir / UNIT_NAME
        unit.write_text(systemd_unit(config), encoding='utf-8')
        run_command(['systemctl', '--user', 'daemon-reload'])
        run_command(['systemctl', '--user', 'enable', '--now', UNIT_NAME])
        return (f'Installed and started {UNIT_NAME}. It runs while your user service manager is active.\n'
                f'For startup before login, an administrator can run: sudo loginctl enable-linger {os.environ.get("USER", "USERNAME")}')
    if action == 'remove':
        run_command(['systemctl', '--user', 'disable', '--now', UNIT_NAME], check=False)
        unit = Path.home() / '.config' / 'systemd' / 'user' / UNIT_NAME
        if unit.exists():
            unit.unlink()
        run_command(['systemctl', '--user', 'daemon-reload'])
        return f'Removed {UNIT_NAME}'
    op = {'start': 'start', 'stop': 'stop', 'restart': 'restart', 'status': 'status'}[action]
    return run_command(['systemctl', '--user', op, UNIT_NAME], check=action != 'status')


def manage_windows(action, config):
    if action == 'install':
        command = subprocess.list2cmdline(command_to_run(config))
        # LocalService is significantly lower-privileged than LocalSystem. It must
        # have READ access to the config/key and WRITE access to the storage root.
        return run_command(['sc.exe', 'create', SERVICE_NAME, 'binPath=', command,
                            'start=', 'auto', 'obj=', 'NT AUTHORITY\\LocalService',
                            'DisplayName=', 'LANBridge Storage']) + ('\nCreated Windows service as LocalService. '
                            'Grant LocalService Modify access to the specific storage folder before starting.')
    if action == 'remove':
        run_command(['sc.exe', 'stop', SERVICE_NAME], check=False)
        return run_command(['sc.exe', 'delete', SERVICE_NAME])
    op = {'start': 'start', 'stop': 'stop', 'restart': 'stop', 'status': 'query'}[action]
    if action == 'restart':
        run_command(['sc.exe', 'stop', SERVICE_NAME], check=False)
        return run_command(['sc.exe', 'start', SERVICE_NAME])
    return run_command(['sc.exe', op, SERVICE_NAME], check=action != 'status')


def manage(action, config):
    if os.name == 'nt':
        return manage_windows(action, config)
    if sys.platform.startswith('linux'):
        return manage_linux(action, config)
    raise RuntimeError('Automatic service management currently supports Windows and systemd Linux.')


def run_windows_service(host_factory):
    """Run genuine Windows service under SCM; host_factory builds the Host."""
    if os.name != 'nt':
        raise RuntimeError('Windows SCM service mode is only for Windows')

    from ctypes import wintypes
    advapi = ctypes.WinDLL('Advapi32', use_last_error=True)
    STOP = 0x00000001
    SHUTDOWN = 0x00000005
    INTERROGATE = 0x00000004
    WIN32_OWN_PROCESS = 0x00000010
    START_PENDING, STOP_PENDING, RUNNING, STOPPED = 2, 3, 4, 1
    ACCEPT_STOP = 0x00000001
    ACCEPT_SHUTDOWN = 0x00000004

    class Status(ctypes.Structure):
        _fields_ = [('dwServiceType', wintypes.DWORD), ('dwCurrentState', wintypes.DWORD),
                    ('dwControlsAccepted', wintypes.DWORD), ('dwWin32ExitCode', wintypes.DWORD),
                    ('dwServiceSpecificExitCode', wintypes.DWORD), ('dwCheckPoint', wintypes.DWORD),
                    ('dwWaitHint', wintypes.DWORD)]

    ServiceMain = ctypes.WINFUNCTYPE(None, wintypes.DWORD, ctypes.POINTER(wintypes.LPWSTR))
    Handler = ctypes.WINFUNCTYPE(wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                ctypes.c_void_p, ctypes.c_void_p)

    class Entry(ctypes.Structure):
        _fields_ = [('lpServiceName', wintypes.LPWSTR), ('lpServiceProc', ServiceMain)]

    advapi.RegisterServiceCtrlHandlerExW.argtypes = [wintypes.LPCWSTR, Handler, ctypes.c_void_p]
    advapi.RegisterServiceCtrlHandlerExW.restype = wintypes.HANDLE
    advapi.SetServiceStatus.argtypes = [wintypes.HANDLE, ctypes.POINTER(Status)]
    advapi.SetServiceStatus.restype = wintypes.BOOL
    advapi.StartServiceCtrlDispatcherW.argtypes = [ctypes.POINTER(Entry)]
    advapi.StartServiceCtrlDispatcherW.restype = wintypes.BOOL

    stopping = threading.Event()
    status_handle = None
    status = Status(WIN32_OWN_PROCESS, START_PENDING, 0, 0, 0, 1, 30000)

    def report(state, exitcode=0):
        status.dwCurrentState = state
        status.dwControlsAccepted = (ACCEPT_STOP | ACCEPT_SHUTDOWN) if state == RUNNING else 0
        status.dwWin32ExitCode = exitcode
        status.dwCheckPoint = 0
        status.dwWaitHint = 0
        if status_handle:
            advapi.SetServiceStatus(status_handle, ctypes.byref(status))

    @Handler
    def control(ctrl, event_type, event_data, context):
        if ctrl in (STOP, SHUTDOWN):
            report(STOP_PENDING)
            stopping.set()
        elif ctrl == INTERROGATE:
            report(status.dwCurrentState)
        return 0

    @ServiceMain
    def main(argc, argv):
        nonlocal status_handle
        status_handle = advapi.RegisterServiceCtrlHandlerExW(SERVICE_NAME, control, None)
        if not status_handle:
            return
        report(START_PENDING)
        host = None
        try:
            host = host_factory()
            host.start()
            report(RUNNING)
            stopping.wait()
            report(STOP_PENDING)
        except Exception:
            # A nonzero service exit code makes failure visible in 'sc query'.
            report(STOPPED, 1066)
            return
        finally:
            if host:
                host.stop()
        report(STOPPED)

    entries = (Entry * 2)(Entry(SERVICE_NAME, main), Entry(None, ServiceMain()))
    if not advapi.StartServiceCtrlDispatcherW(entries):
        raise OSError(ctypes.get_last_error(), 'Windows SCM rejected service launch')
