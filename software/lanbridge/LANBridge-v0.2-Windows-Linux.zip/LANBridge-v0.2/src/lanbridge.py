#!/usr/bin/env python3
"""LANBridge: direct-IP, TLS-pinned LAN transfer + native SMB drive mapping.
Python 3.10+; dependency: cryptography. UI requires tkinter.
"""
from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import hashlib
import http.client
import http.server
import ipaddress
import json
import getpass
import os
from pathlib import Path
import queue
import re
import secrets
import signal
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse

APP = "LANBridge"
PORT = 8537
CONFIG_DIR = Path.home() / ".lanbridge"
MAX_TRANSFER = 2 * 1024**4  # 2 TiB per file, streamed; no RAM buffering
CHUNK = 1024 * 1024
VERSION = 2
DEFAULT_NETWORKS = ("127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16")


def app_dir():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if os.name != "nt":
        CONFIG_DIR.chmod(0o700)
    return CONFIG_DIR


def certificate_files():
    """Create a stable, self-signed TLS identity per host; clients pin SHA-256."""
    cert = app_dir() / "host.crt"
    key = app_dir() / "host.key"
    if not (cert.is_file() and key.is_file()):
        try:
            from cryptography import x509
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import ec
            from cryptography.x509.oid import NameOID
        except ImportError as e:
            raise RuntimeError("Install TLS dependency: python -m pip install cryptography") from e
        private = ec.generate_private_key(ec.SECP256R1())
        subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "LANBridge device")])
        now = dt.datetime.now(dt.timezone.utc)
        signed = (
            x509.CertificateBuilder().subject_name(subject).issuer_name(subject)
            .public_key(private.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - dt.timedelta(days=1))
            .not_valid_after(now + dt.timedelta(days=3650))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .sign(private, hashes.SHA256())
        )
        # Do not write a new key over an existing identity; that would break pinning.
        if cert.exists() or key.exists():
            raise RuntimeError("Incomplete TLS identity: back up and repair ~/.lanbridge/host.crt and host.key")
        key.write_bytes(private.private_bytes(serialization.Encoding.PEM,
                         serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        if os.name != "nt":
            key.chmod(0o600)
        cert.write_bytes(signed.public_bytes(serialization.Encoding.PEM))
    der = ssl.PEM_cert_to_DER_cert(cert.read_text(encoding="ascii"))
    return cert, key, hashlib.sha256(der).hexdigest().upper()


def tls_context_client():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE  # certificate pinned manually BEFORE any secret is sent
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    return context


def certificate_fingerprint(host, port, timeout=4):
    with socket.create_connection((host, int(port)), timeout=timeout) as sock:
        with tls_context_client().wrap_socket(sock, server_hostname=host) as secure:
            return hashlib.sha256(secure.getpeercert(binary_form=True)).hexdigest().upper()


def check_relative(raw, allow_root=True):
    """Reject traversal, separators normalized ambiguously, absolute paths and NULs."""
    if not isinstance(raw, str) or "\\" in raw or "\x00" in raw or raw.startswith("/"):
        raise ValueError("Invalid relative path")
    if raw in ("", "."):
        if allow_root:
            return Path(".")
        raise ValueError("Specify a file or folder")
    parts = raw.split("/")
    if any(s in ("", ".", "..") or ":" in s for s in parts):
        raise ValueError("Unsafe path component")
    return Path(*parts)


def checked_path(root, raw, allow_root=True):
    rel = check_relative(raw, allow_root)
    root = root.resolve(strict=True)
    candidate = root / rel
    resolved = candidate.resolve(strict=False)
    if os.path.commonpath((str(root), str(resolved))) != str(root):
        raise ValueError("Path escapes shared folder")
    return candidate


def reljoin(folder, name):
    check_relative(name, False)
    if "/" in name:
        raise ValueError("Expected a single file name")
    return folder + "/" + name if folder else name


def storage_info(root):
    usage = shutil.disk_usage(root)
    return {"free": usage.free, "total": usage.total}


def make_handler(root, access_key, writable, backup_only=False, allow_networks=DEFAULT_NETWORKS, max_transfers=2):
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Share root must be a directory")
    allowed = tuple(ipaddress.ip_network(n, strict=False) for n in allow_networks)
    transfers = threading.BoundedSemaphore(max_transfers)
    failures = {}
    failures_lock = threading.Lock()

    class TransferHandler(http.server.BaseHTTPRequestHandler):
        server_version = "LANBridge/1"
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            # Access secrets are never included in request URLs or log lines.
            sys.stderr.write("[LANBridge %s] %s\n" % (self.address_string(), fmt % args))

        def json_reply(self, status, data):
            payload = json.dumps(data).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.close_connection = True
            self.end_headers()
            self.wfile.write(payload)

        def authenticate(self):
            addr = self.client_address[0]
            if not any(ipaddress.ip_address(addr) in block for block in allowed):
                self.json_reply(403, {"error": "This client network is not authorized"})
                return False
            now = time.monotonic()
            with failures_lock:
                prior = failures.get(addr, [])
                recent = [t for t in prior if now - t < 60]
                failures[addr] = recent
                blocked = len(recent) >= 6
            if blocked:
                self.json_reply(429, {"error": "Too many failed logins; retry after 60 seconds"})
                return False
            provided = self.headers.get("X-LANBridge-Key", "")
            if not secrets.compare_digest(provided, access_key):
                with failures_lock:
                    failures.setdefault(addr, []).append(now)
                self.json_reply(403, {"error": "Invalid access key"})
                return False
            with failures_lock:
                failures.pop(addr, None)
            return True

        def parsed(self):
            path = urllib.parse.urlsplit(self.path)
            params = urllib.parse.parse_qs(path.query, keep_blank_values=True)
            return path.path, params.get("path", [""])[0]

        def do_GET(self):
            if not self.authenticate():
                return
            try:
                endpoint, relative = self.parsed()
                if endpoint == "/api/info":
                    self.json_reply(200, {"version": VERSION, "host": socket.gethostname(),
                                          "writable": writable, "mode": "backup" if backup_only else ("files" if writable else "readonly"), **storage_info(root)})
                elif endpoint == "/api/list":
                    directory = checked_path(root, relative)
                    if not directory.is_dir():
                        return self.json_reply(404, {"error": "Folder not found"})
                    entries = []
                    for p in directory.iterdir():
                        if p.is_symlink():
                            continue
                        try:
                            stat = p.stat()
                            isdir = p.is_dir()
                            if not (isdir or p.is_file()):
                                continue
                            entries.append({"name": p.name, "dir": isdir,
                                            "size": 0 if isdir else stat.st_size})
                        except OSError:
                            continue
                    entries.sort(key=lambda x: (not x["dir"], x["name"].casefold()))
                    self.json_reply(200, {"entries": entries, "path": relative})
                elif endpoint == "/api/download":
                    file = checked_path(root, relative, allow_root=False)
                    if not file.is_file() or file.is_symlink():
                        return self.json_reply(404, {"error": "File not found"})
                    if not transfers.acquire(blocking=False):
                        return self.json_reply(429, {"error": "Transfer capacity reached; retry shortly"})
                    try:
                        with open(file, "rb") as src:
                            self.send_response(200)
                            self.send_header("Content-Type", "application/octet-stream")
                            self.send_header("Content-Length", str(os.fstat(src.fileno()).st_size))
                            self.send_header("Cache-Control", "no-store")
                            self.send_header("Connection", "close")
                            self.close_connection = True
                            self.end_headers()
                            shutil.copyfileobj(src, self.wfile, CHUNK)
                    finally:
                        transfers.release()
                else:
                    self.json_reply(404, {"error": "Unknown API path"})
            except (ValueError, PermissionError, OSError) as e:
                self.json_reply(400, {"error": str(e)})

        def do_POST(self):
            if not self.authenticate():
                return
            if not writable:
                return self.json_reply(403, {"error": "Uploads disabled on host"})
            try:
                endpoint, relative = self.parsed()
                target = checked_path(root, relative, allow_root=False)
                if endpoint == "/api/check-upload":
                    params = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                    size_str = params.get("size", [""])[0]
                    overwrite = params.get("overwrite", [""])[0] == "yes"
                    if not size_str.isdecimal():
                        return self.json_reply(400, {"error": "Invalid upload size"})
                    if int(size_str) > MAX_TRANSFER:
                        return self.json_reply(413, {"error": "File exceeds 2 TiB transfer limit"})
                    if target.exists() and (target.is_dir() or backup_only or not overwrite):
                        return self.json_reply(409, {"error": "File exists (overwrite not authorized)"})
                    if int(size_str) > shutil.disk_usage(root).free:
                        return self.json_reply(507, {"error": "Insufficient free space"})
                    return self.json_reply(200, {"ok": True})
                if endpoint == "/api/mkdir":
                    target.mkdir(parents=True, exist_ok=True)
                    target = checked_path(root, relative, allow_root=False)
                    if not target.is_dir():
                        raise ValueError("Not a directory")
                    return self.json_reply(200, {"ok": True})
                if endpoint != "/api/upload":
                    return self.json_reply(404, {"error": "Unknown API path"})
                if target.exists() and (target.is_dir() or backup_only or
                                        self.headers.get("X-Overwrite") != "yes"):
                    return self.json_reply(409, {"error": "File exists (overwrite not authorized)"})
                length_header = self.headers.get("Content-Length", "")
                if not length_header.isdecimal():
                    return self.json_reply(411, {"error": "Content-Length required"})
                remaining = int(length_header)
                if remaining > MAX_TRANSFER:
                    return self.json_reply(413, {"error": "File exceeds 2 TiB transfer limit"})
                if remaining > shutil.disk_usage(root).free:
                    return self.json_reply(507, {"error": "Insufficient free space"})
                target.parent.mkdir(parents=True, exist_ok=True)
                checked_path(root, relative, allow_root=False)  # recheck after mkdir
                if not transfers.acquire(blocking=False):
                    return self.json_reply(429, {"error": "Transfer capacity reached; retry shortly"})
                try:
                    fd, name = tempfile.mkstemp(prefix=".lanbridge-", dir=target.parent)
                    digest = hashlib.sha256()
                    try:
                        with os.fdopen(fd, "wb") as tmp:
                            while remaining:
                                data = self.rfile.read(min(CHUNK, remaining))
                                if not data:
                                    raise ConnectionError("Upload was interrupted")
                                tmp.write(data)
                                digest.update(data)
                                remaining -= len(data)
                            if backup_only:
                                tmp.flush()
                                os.fsync(tmp.fileno())
                        expected = self.headers.get("X-Content-SHA256", "")
                        if expected and not secrets.compare_digest(expected.upper(), digest.hexdigest().upper()):
                            return self.json_reply(422, {"error": "Upload SHA-256 mismatch"})
                        if target.exists() and (backup_only or self.headers.get("X-Overwrite") != "yes"):
                            raise FileExistsError("File already exists")
                        if backup_only:
                            # Publish without ever replacing an existing backup. Linking is
                            # atomic and fails if the destination already exists on POSIX;
                            # Windows os.rename likewise does not replace existing files.
                            if os.name == "nt":
                                os.rename(name, target)
                            else:
                                os.link(name, target)
                        else:
                            os.replace(name, target)
                    finally:
                        if os.path.exists(name):
                            os.unlink(name)
                finally:
                    transfers.release()
                self.json_reply(200, {"ok": True, "sha256": digest.hexdigest()})
            except FileExistsError as e:
                self.json_reply(409, {"error": str(e)})
            except (ValueError, PermissionError, OSError) as e:
                self.json_reply(400, {"error": str(e)})
            except ConnectionError:
                self.close_connection = True

    return TransferHandler


class QuietHTTPServer(http.server.ThreadingHTTPServer):
    daemon_threads = True

    def process_request(self, request, client_address):
        if not self.connection_limit.acquire(blocking=False):
            request.close()
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.connection_limit.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            # TLS handshake inside a bounded worker, not on the single accept
            # thread. A stalled client must not freeze every other connection.
            request.settimeout(15)
            with self.tls_context.wrap_socket(request, server_side=True) as secure:
                super().process_request_thread(secure, client_address)
        except (ssl.SSLError, TimeoutError, ConnectionError, OSError):
            pass
        finally:
            request.close()
            self.connection_limit.release()

    def handle_error(self, request, client_address):
        error = sys.exc_info()[1]
        if isinstance(error, (BrokenPipeError, ConnectionResetError, ssl.SSLEOFError)):
            return  # normal: TLS fingerprint probe closes without sending HTTP
        super().handle_error(request, client_address)


class Host:
    def __init__(self, root, port=PORT, writable=False, bind="0.0.0.0", key=None,
                 mode=None, allow_networks=DEFAULT_NETWORKS, max_clients=8, max_transfers=2):
        self.root = Path(root).expanduser().resolve(strict=True)
        self.key = key or secrets.token_hex(16).upper()  # 128-bit ephemeral; 256-bit persistent key from configure
        self.mode = mode or ("files" if writable else "readonly")
        if self.mode not in ("readonly", "files", "backup"):
            raise ValueError("Invalid host mode")
        if not 1 <= int(max_clients) <= 128 or not 1 <= int(max_transfers) <= int(max_clients):
            raise ValueError("Invalid connection/transfer limits")
        self.port = int(port)
        cert, private, self.fingerprint = certificate_files()
        server = QuietHTTPServer((bind, self.port),
                    make_handler(self.root, self.key, self.mode != "readonly", self.mode == "backup",
                                 allow_networks, int(max_transfers)))
        server.connection_limit = threading.BoundedSemaphore(int(max_clients))
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(str(cert), str(private))
        server.tls_context = ctx
        self.server = server
        self.port = server.server_port
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        if self.thread:
            self.thread.join(timeout=3)


class BridgeClient:
    def __init__(self, host, port, key, fingerprint):
        self.host = host.strip()
        self.port = int(port)
        self.key = key.strip()
        self.fingerprint = fingerprint.replace(":", "").replace(" ", "").upper()
        if len(self.fingerprint) != 64 or not re.fullmatch(r"[0-9A-F]{64}", self.fingerprint):
            raise ValueError("A complete trusted server fingerprint is required")
        if not self.key:
            raise ValueError("A pairing code is required")

    def connection(self):
        conn = http.client.HTTPSConnection(self.host, self.port,
                         timeout=30, context=tls_context_client())
        conn.connect()
        cert = conn.sock.getpeercert(binary_form=True)
        actual = hashlib.sha256(cert).hexdigest().upper()
        if not secrets.compare_digest(actual, self.fingerprint):
            conn.close()
            raise ssl.SSLError("Server identity changed! Refusing to send the pairing code.")
        return conn

    @staticmethod
    def check_response(response):
        if response.status >= 400:
            error = response.read(2048).decode("utf-8", "replace")
            try:
                error = json.loads(error)["error"]
            except (ValueError, KeyError, TypeError):
                pass
            raise RuntimeError(f"Remote error {response.status}: {error}")

    def json(self, method, endpoint, path=""):
        conn = self.connection()
        try:
            target = endpoint + ("&" if "?" in endpoint else "?") + urllib.parse.urlencode({"path": path})
            conn.request(method, target, headers={"X-LANBridge-Key": self.key})
            response = conn.getresponse()
            self.check_response(response)
            return json.loads(response.read().decode("utf-8"))
        finally:
            conn.close()

    def info(self):
        return self.json("GET", "/api/info")

    def list(self, path=""):
        return self.json("GET", "/api/list", path)["entries"]

    def mkdir(self, path):
        return self.json("POST", "/api/mkdir", path)

    def download(self, remote, local, progress=None):
        target = Path(local)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            raise FileExistsError(f"Destination already exists: {target}")
        conn = self.connection()
        temp_name = None
        try:
            endpoint = "/api/download?" + urllib.parse.urlencode({"path": remote})
            conn.request("GET", endpoint, headers={"X-LANBridge-Key": self.key})
            response = conn.getresponse()
            self.check_response(response)
            length = int(response.getheader("Content-Length", "0"))
            fd, temp_name = tempfile.mkstemp(prefix=".lanbridge-", dir=target.parent)
            with os.fdopen(fd, "wb") as output:
                count = 0
                while True:
                    block = response.read(CHUNK)
                    if not block:
                        break
                    output.write(block)
                    count += len(block)
                    if progress:
                        progress(count, length)
            if count != length:
                raise IOError("Incomplete download")
            if target.exists():
                raise FileExistsError(f"Destination already exists: {target}")
            os.replace(temp_name, target)
            temp_name = None
        finally:
            conn.close()
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)

    def upload(self, local, remote, overwrite=False, progress=None, verify=True, preflight=True):
        local = Path(local)
        size = local.stat().st_size
        if size > MAX_TRANSFER:
            raise ValueError("File exceeds 2 TiB transfer limit")
        check_endpoint = ("/api/check-upload?size=" + str(size) +
                          "&overwrite=" + ("yes" if overwrite else "no"))
        if preflight:
            self.json("POST", check_endpoint, remote)
        conn = self.connection()
        try:
            endpoint = "/api/upload?" + urllib.parse.urlencode({"path": remote})
            conn.putrequest("POST", endpoint)
            conn.putheader("X-LANBridge-Key", self.key)
            conn.putheader("X-Overwrite", "yes" if overwrite else "no")
            conn.putheader("Content-Type", "application/octet-stream")
            conn.putheader("Content-Length", str(size))
            conn.endheaders()
            digest = hashlib.sha256()
            with local.open("rb") as f:
                count = 0
                while chunk := f.read(CHUNK):
                    conn.send(chunk)
                    if verify:
                        digest.update(chunk)
                    count += len(chunk)
                    if progress:
                        progress(count, size)
            response = conn.getresponse()
            self.check_response(response)
            result = json.loads(response.read())
            if verify and not secrets.compare_digest(digest.hexdigest(), result.get("sha256", "")):
                raise IOError("Remote SHA-256 differs from the sent data")
            return result
        finally:
            conn.close()


def local_ipv4():
    addresses = set()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.0.2.1", 80))  # route lookup only; sends no network packet
            addresses.add(s.getsockname()[0])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            addresses.add(info[4][0])
    except OSError:
        pass
    return sorted(x for x in addresses if not x.startswith("127.")) or ["127.0.0.1"]


def read_pins():
    file = app_dir() / "trusted.json"
    try:
        data = json.loads(file.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_pin(identity, fingerprint):
    trusted = read_pins()
    trusted[identity] = fingerprint
    target = app_dir() / "trusted.json"
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(trusted, indent=2), encoding="utf-8")
    os.replace(temp, target)


def windows_share(root, name):
    if os.name != "nt":
        raise RuntimeError("Creating native SMB shares is Windows-only")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,32}", name):
        raise ValueError("Share name must contain 1-32 letters, numbers, _ or -")
    user = subprocess.check_output(["whoami"], text=True).strip()
    ps_quote = lambda s: "'" + str(s).replace("'", "''") + "'"
    command = ("$ErrorActionPreference='Stop'; New-SmbShare "
               f"-Name {ps_quote(name)} -Path {ps_quote(str(Path(root).resolve()))} "
               f"-ChangeAccess {ps_quote(user)} -EncryptData $true -Confirm:$false | Out-Null; "
               "Write-Output 'Share created'")
    run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
                         text=True, capture_output=True, timeout=30)
    if run.returncode:
        raise RuntimeError((run.stderr or run.stdout).strip() +
                "\nTry running LANBridge as Administrator for SMB share creation.")
    return run.stdout.strip()


def windows_map(host, share, drive, username="", password=""):
    if os.name != "nt":
        raise RuntimeError("Drive-letter mapping is Windows-only")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", host):
        raise ValueError("Enter a hostname or IPv4 address")
    if not re.fullmatch(r"[A-Za-z0-9_$-]{1,80}", share):
        raise ValueError("Invalid SMB share name")
    if not re.fullmatch(r"[A-Za-z]", drive):
        raise ValueError("Drive letter must be a single letter")
    from ctypes import wintypes
    class NETRESOURCEW(ctypes.Structure):
        _fields_ = [("dwScope", wintypes.DWORD), ("dwType", wintypes.DWORD),
                    ("dwDisplayType", wintypes.DWORD), ("dwUsage", wintypes.DWORD),
                    ("lpLocalName", wintypes.LPWSTR), ("lpRemoteName", wintypes.LPWSTR),
                    ("lpComment", wintypes.LPWSTR), ("lpProvider", wintypes.LPWSTR)]
    resource = NETRESOURCEW(0, 1, 0, 0, drive.upper() + ":", f"\\\\{host}\\{share}", None, None)
    mpr = ctypes.WinDLL("mpr", use_last_error=True)
    mpr.WNetAddConnection2W.argtypes = [ctypes.POINTER(NETRESOURCEW), wintypes.LPCWSTR,
                                       wintypes.LPCWSTR, wintypes.DWORD]
    mpr.WNetAddConnection2W.restype = wintypes.DWORD
    result = mpr.WNetAddConnection2W(ctypes.byref(resource), password or None, username or None, 1)
    if result != 0:
        raise OSError(f"Windows SMB mapping failed ({result}): {ctypes.FormatError(result).strip()}")
    return f"{drive.upper()}: → \\\\{host}\\{share}"


def smb_port_test(host):
    try:
        with socket.create_connection((host, 445), timeout=3):
            return "Port 445 reachable. SMB may be available; credentials still required."
    except OSError as e:
        return f"Port 445 unreachable ({e}). The independent LANBridge transfer can still work."


def fmt_bytes(value):
    value = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024 or unit == "TiB":
            return f"{value:.1f} {unit}"
        value /= 1024


def gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    class Window:
        def __init__(self):
            self.root = tk.Tk()
            self.root.title("LANBridge — LAN Storage")
            self.root.geometry("825x655")
            self.root.minsize(690, 550)
            self.host = None
            self.client = None
            self.remote_dir = ""
            self.entries = {}
            self.events = queue.Queue()
            self.busy = False
            self.host_dir = tk.StringVar(value="")
            self.port = tk.StringVar(value=str(PORT))
            self.allow_uploads = tk.BooleanVar(value=True)
            self.protect_backups = tk.BooleanVar(value=True)
            self.service_mode = tk.StringVar(value="backup")
            self.service_config = tk.StringVar(value=str(service_config_file()))
            self.service_key = tk.StringVar(value="—")
            self.service_fp = tk.StringVar(value="—")
            self.host_code = tk.StringVar(value="—")
            self.host_fp = tk.StringVar(value="—")
            self.remote_host = tk.StringVar(value="")
            self.remote_port = tk.StringVar(value=str(PORT))
            self.remote_code = tk.StringVar(value="")
            self.remote_status = tk.StringVar(value="Not connected")
            self.remote_path = tk.StringVar(value="/")
            self.overwrite = tk.BooleanVar(value=False)
            self.share_name = tk.StringVar(value="Storage")
            self.drive_letter = tk.StringVar(value="Z")
            self.smb_username = tk.StringVar(value="")
            self.smb_password = tk.StringVar(value="")
            self.status = tk.StringVar(value="Ready. All file transfers use encrypted TLS.")
            self.build()
            self.root.protocol("WM_DELETE_WINDOW", self.close)
            self.root.after(100, self.drain)

        def worker(self, func, refresh=False):
            if self.busy:
                return
            self.busy = True
            def run():
                try:
                    result = func()
                    self.events.put(("result", result, refresh))
                except Exception as exc:
                    self.events.put(("error", str(exc)))
                finally:
                    self.events.put(("idle",))
            threading.Thread(target=run, daemon=True).start()

        def drain(self):
            try:
                while True:
                    event = self.events.get_nowait()
                    kind = event[0]
                    if kind == "status":
                        self.status.set(event[1])
                    elif kind == "listing":
                        self.show_entries(event[1], event[2])
                    elif kind == "connected":
                        self.remote_status.set(event[1])
                    elif kind == "result":
                        if event[1]:
                            self.status.set(str(event[1]))
                        if event[2]:
                            self.root.after(120, self.refresh)
                    elif kind == "error":
                        self.status.set("Error: " + event[1])
                        messagebox.showerror("LANBridge", event[1])
                    elif kind == "idle":
                        self.busy = False
            except queue.Empty:
                pass
            self.root.after(100, self.drain)

        def build(self):
            r = self.root
            tabs = ttk.Notebook(r)
            tabs.pack(fill="both", expand=True, padx=10, pady=8)
            share = ttk.Frame(tabs, padding=12)
            transfers = ttk.Frame(tabs, padding=12)
            smb = ttk.Frame(tabs, padding=12)
            tabs.add(share, text="Share this computer")
            tabs.add(transfers, text="Browse / Transfer")
            tabs.add(smb, text="Map network drive")
            background = ttk.Frame(tabs, padding=12)
            tabs.add(background, text="Background host")

            ttk.Label(share, text="Folder to make available to other LANBridge devices:").pack(anchor="w")
            line = ttk.Frame(share); line.pack(fill="x", pady=5)
            ttk.Entry(line, textvariable=self.host_dir).pack(side="left", fill="x", expand=True)
            ttk.Button(line, text="Browse…", command=self.select_host_dir).pack(side="left", padx=5)
            line2 = ttk.Frame(share); line2.pack(fill="x", pady=6)
            ttk.Label(line2, text="Port:").pack(side="left")
            ttk.Entry(line2, textvariable=self.port, width=7).pack(side="left", padx=6)
            ttk.Checkbutton(line2, text="Allow remote uploads", variable=self.allow_uploads).pack(side="left", padx=8)
            ttk.Checkbutton(share, text="Protect existing files (backup mode: no overwrites)",
                            variable=self.protect_backups).pack(anchor="w", padx=8)
            self.start_btn = ttk.Button(line2, text="Start hosting", command=self.toggle_host)
            self.start_btn.pack(side="right")
            ttk.Separator(share).pack(fill="x", pady=12)
            ttk.Label(share, text="Local IP address(es): " + ", ".join(local_ipv4()),
                      font=("TkDefaultFont", 11, "bold")).pack(anchor="w", pady=4)
            ttk.Label(share, text="Pairing code (changes each hosting session):").pack(anchor="w")
            row = ttk.Frame(share); row.pack(fill="x", pady=4)
            ttk.Entry(row, textvariable=self.host_code, width=22, state="readonly").pack(side="left")
            ttk.Button(row, text="Copy code", command=lambda: self.copy(self.host_code.get())).pack(side="left", padx=7)
            ttk.Label(share, text="Host identity fingerprint (compare on the other computer before trusting):").pack(anchor="w", pady=(13, 2))
            row = ttk.Frame(share); row.pack(fill="x")
            ttk.Entry(row, textvariable=self.host_fp, state="readonly").pack(side="left", fill="x", expand=True)
            ttk.Button(row, text="Copy", command=lambda: self.copy(self.host_fp.get())).pack(side="left", padx=7)
            ttk.Label(share, text="No discovery required. Use the host's IPv4 address, port and code on the other PC.\n"
                       "Keep the host running while accessing files. Only share folders you intend to expose.",
                      justify="left", wraplength=730).pack(anchor="w", pady=20)

            top = ttk.Frame(transfers); top.pack(fill="x")
            ttk.Label(top, text="Host IP:").pack(side="left")
            ttk.Entry(top, textvariable=self.remote_host, width=19).pack(side="left", padx=5)
            ttk.Label(top, text="Port:").pack(side="left")
            ttk.Entry(top, textvariable=self.remote_port, width=7).pack(side="left", padx=5)
            ttk.Label(top, text="Code:").pack(side="left")
            ttk.Entry(top, textvariable=self.remote_code, width=17, show="•").pack(side="left", padx=5)
            ttk.Button(top, text="Connect", command=self.connect).pack(side="left", padx=5)
            ttk.Label(transfers, textvariable=self.remote_status).pack(anchor="w", pady=8)
            nav = ttk.Frame(transfers); nav.pack(fill="x")
            ttk.Button(nav, text="↑ Parent", command=self.parent).pack(side="left")
            ttk.Button(nav, text="Refresh", command=self.refresh).pack(side="left", padx=5)
            ttk.Label(nav, textvariable=self.remote_path).pack(side="left", padx=10)
            treeframe = ttk.Frame(transfers); treeframe.pack(fill="both", expand=True, pady=7)
            self.tree = ttk.Treeview(treeframe, columns=("type", "size"), show="tree headings", selectmode="extended")
            self.tree.heading("#0", text="Name"); self.tree.heading("type", text="Type"); self.tree.heading("size", text="Size")
            self.tree.column("#0", width=405); self.tree.column("type", width=95); self.tree.column("size", width=115, anchor="e")
            scroll = ttk.Scrollbar(treeframe, command=self.tree.yview)
            self.tree.configure(yscrollcommand=scroll.set)
            self.tree.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            self.tree.bind("<Double-1>", self.open_entry)
            controls = ttk.Frame(transfers); controls.pack(fill="x", pady=4)
            ttk.Button(controls, text="Download selected", command=self.download_selection).pack(side="left", padx=3)
            ttk.Button(controls, text="Upload files…", command=self.upload_files).pack(side="left", padx=3)
            ttk.Button(controls, text="Upload folder…", command=self.upload_folder).pack(side="left", padx=3)
            ttk.Checkbutton(controls, text="Overwrite remote files", variable=self.overwrite).pack(side="left", padx=8)

            ttk.Label(smb, text="Native SMB sharing and drive mapping (independent of LANBridge transfers)",
                      font=("TkDefaultFont", 11, "bold")).pack(anchor="w", pady=5)
            ttk.Label(smb, text="1. On the computer containing the storage, create an SMB share.\n"
                                "2. On the other computer, map it using the IP address and share name.\n"
                                "SMB uses Windows account permissions and TCP port 445; no network discovery needed.",
                      justify="left", wraplength=745).pack(anchor="w", pady=8)
            hostrow = ttk.Frame(smb); hostrow.pack(fill="x", pady=6)
            ttk.Label(hostrow, text="Share name:").pack(side="left")
            ttk.Entry(hostrow, textvariable=self.share_name, width=23).pack(side="left", padx=8)
            if os.name == "nt":
                ttk.Button(hostrow, text="Create Windows SMB share (Admin)", command=self.create_share).pack(side="left")
            else:
                ttk.Label(hostrow, text="On Linux, configure Samba separately to export a folder.").pack(side="left")
            ttk.Separator(smb).pack(fill="x", pady=15)
            row = ttk.Frame(smb); row.pack(fill="x", pady=4)
            ttk.Label(row, text="Server IP:").pack(side="left")
            ttk.Entry(row, textvariable=self.remote_host, width=19).pack(side="left", padx=6)
            ttk.Label(row, text="Share:").pack(side="left")
            ttk.Entry(row, textvariable=self.share_name, width=20).pack(side="left", padx=6)
            ttk.Label(row, text="Drive:").pack(side="left")
            ttk.Entry(row, textvariable=self.drive_letter, width=3).pack(side="left", padx=6)
            row = ttk.Frame(smb); row.pack(fill="x", pady=4)
            ttk.Label(row, text="Username (optional):").pack(side="left")
            ttk.Entry(row, textvariable=self.smb_username, width=30).pack(side="left", padx=5)
            ttk.Label(row, text="Password:").pack(side="left")
            ttk.Entry(row, textvariable=self.smb_password, show="•", width=25).pack(side="left", padx=5)
            row = ttk.Frame(smb); row.pack(fill="x", pady=8)
            ttk.Button(row, text="Check SMB port 445", command=self.check_smb).pack(side="left", padx=3)
            if os.name == "nt":
                ttk.Button(row, text="Map as Windows drive", command=self.map_drive).pack(side="left", padx=3)
            else:
                ttk.Button(row, text="Open SMB in file manager", command=self.open_linux_smb).pack(side="left", padx=3)
            ttk.Label(smb, text="For Windows shares, use HOSTNAME\\username and its Windows password. "
                     "Do not enable SMB1, guest access, or disable your firewall.\n"
                     "On Linux, mount.cifs provides a filesystem mount; see README.",
                      justify="left", wraplength=745).pack(anchor="w", pady=12)

            ttk.Label(background, text="Keep storage online without leaving this window open",
                      font=("TkDefaultFont", 11, "bold")).pack(anchor="w", pady=5)
            ttk.Label(background, text="1. Select the storage folder in the first tab.\n"
                                        "2. Save a persistent host configuration and copy its fingerprint/key.\n"
                                        "3. Install/start the background service. Windows requires Administrator access and a folder ACL for LocalService.\n"
                                        "Linux uses your systemd user service (boot-time startup requires user lingering).",
                      justify="left", wraplength=740).pack(anchor="w", pady=7)
            row = ttk.Frame(background); row.pack(fill="x", pady=6)
            ttk.Label(row, text="Storage mode:").pack(side="left")
            ttk.Combobox(row, textvariable=self.service_mode, values=("backup", "readonly", "files"),
                         state="readonly", width=12).pack(side="left", padx=8)
            ttk.Label(row, text="Port:").pack(side="left", padx=(10, 0))
            ttk.Label(row, textvariable=self.port).pack(side="left", padx=6)
            ttk.Label(background, text="Configuration file:").pack(anchor="w", pady=(8, 2))
            ttk.Entry(background, textvariable=self.service_config, state="readonly").pack(fill="x")
            row = ttk.Frame(background); row.pack(fill="x", pady=12)
            ttk.Button(row, text="Save host configuration", command=self.save_background_config).pack(side="left", padx=4)
            ttk.Button(row, text="Install service", command=lambda: self.service_action("install")).pack(side="left", padx=4)
            ttk.Button(row, text="Start", command=lambda: self.service_action("start")).pack(side="left", padx=4)
            ttk.Button(row, text="Stop", command=lambda: self.service_action("stop")).pack(side="left", padx=4)
            ttk.Button(row, text="Status", command=lambda: self.service_action("status")).pack(side="left", padx=4)
            ttk.Label(background, text="Persistent access key (share only with trusted clients):").pack(anchor="w")
            row = ttk.Frame(background); row.pack(fill="x", pady=3)
            ttk.Entry(row, textvariable=self.service_key, state="readonly").pack(side="left", fill="x", expand=True)
            ttk.Button(row, text="Copy key", command=lambda: self.copy(self.service_key.get())).pack(side="left", padx=5)
            ttk.Label(background, text="SHA-256 certificate fingerprint:").pack(anchor="w", pady=(10, 1))
            row = ttk.Frame(background); row.pack(fill="x")
            ttk.Entry(row, textvariable=self.service_fp, state="readonly").pack(side="left", fill="x", expand=True)
            ttk.Button(row, text="Copy", command=lambda: self.copy(self.service_fp.get())).pack(side="left", padx=5)
            ttk.Label(background, text="Caution: installing a Windows service without granting LocalService access to the\n"
                                        "storage folder will fail to start. The standalone Windows setup script can configure permissions.",
                      wraplength=740, justify="left").pack(anchor="w", pady=14)

            ttk.Separator(r).pack(fill="x")
            ttk.Label(r, textvariable=self.status, anchor="w", wraplength=800).pack(fill="x", padx=12, pady=7)

        def copy(self, value):
            self.root.clipboard_clear(); self.root.clipboard_append(value)
            self.status.set("Copied to clipboard")

        def select_host_dir(self):
            selected = filedialog.askdirectory(initialdir=self.host_dir.get() or str(Path.home()))
            if selected:
                self.host_dir.set(selected)

        def toggle_host(self):
            try:
                if self.host:
                    self.host.stop(); self.host = None
                    self.start_btn.config(text="Start hosting")
                    self.host_code.set("—"); self.host_fp.set("—")
                    self.status.set("Host stopped")
                else:
                    if not self.host_dir.get().strip():
                        raise ValueError("Choose the folder you want to share first")
                    chosen_mode = ("readonly" if not self.allow_uploads.get()
                                   else "backup" if self.protect_backups.get() else "files")
                    server = Host(self.host_dir.get(), int(self.port.get()),
                                  mode=chosen_mode)
                    server.start()
                    self.host = server
                    self.host_code.set(server.key)
                    self.host_fp.set(server.fingerprint)
                    self.start_btn.config(text="Stop hosting")
                    self.status.set(f"Hosting {server.root} via TLS on port {server.port}")
            except Exception as e:
                messagebox.showerror("LANBridge host", str(e))

        def connect(self):
            host = self.remote_host.get().strip()
            if not host:
                return messagebox.showerror("Connect", "Enter the host IP address")
            try:
                port = int(self.remote_port.get())
                actual = certificate_fingerprint(host, port)
                pin_key = f"{host}:{port}"
                pins = read_pins()
                known = pins.get(pin_key)
                if known and actual != known:
                    raise ssl.SSLError("Known device identity changed. Connection blocked.\n"
                                       "Check the other machine's identity before updating trust.")
                if not known:
                    ok = messagebox.askyesno("Trust this device?",
                          f"First connection to {pin_key}.\n\nServer certificate SHA-256:\n{actual}\n\n"
                          "Compare this with the fingerprint displayed on the HOST machine.\n"
                          "Only select Yes if they MATCH exactly.\n\nTrust and pin this device?")
                    if not ok:
                        return
                    save_pin(pin_key, actual)
                client = BridgeClient(host, port, self.remote_code.get(), actual)
                self.client = client
                self.remote_dir = ""
                self.worker(lambda: self.fetch_info(client))
            except Exception as e:
                messagebox.showerror("Connect", str(e))

        def fetch_info(self, client):
            info = client.info()
            if info.get("version") != VERSION:
                raise RuntimeError("Incompatible LANBridge protocol version")
            self.events.put(("connected", f"Connected to {info['host']} — "
                              f"{fmt_bytes(info['free'])} available of {fmt_bytes(info['total'])} "
                              f"— uploads {'enabled' if info['writable'] else 'disabled'}"))
            entries = client.list("")
            self.events.put(("listing", "", entries))
            return "Connected securely"

        def show_entries(self, folder, entries):
            self.remote_dir = folder
            self.remote_path.set("/" + folder)
            self.entries.clear()
            self.tree.delete(*self.tree.get_children())
            for idx, item in enumerate(entries):
                name = item.get("name", "")
                try:
                    reljoin("", name)
                except ValueError:
                    continue
                row_id = str(idx)
                self.entries[row_id] = item
                self.tree.insert("", "end", iid=row_id, text=("📁 " if item["dir"] else "") + name,
                                 values=("Folder" if item["dir"] else "File",
                                         "" if item["dir"] else fmt_bytes(item["size"])))

        def load_folder(self, folder):
            if not self.client:
                return
            client = self.client
            def action():
                entries = client.list(folder)
                self.events.put(("listing", folder, entries))
                return None
            self.worker(action)

        def refresh(self):
            self.load_folder(self.remote_dir)

        def parent(self):
            self.load_folder(self.remote_dir.rsplit("/", 1)[0] if "/" in self.remote_dir else "")

        def open_entry(self, event=None):
            selected = self.tree.selection()
            if len(selected) == 1:
                entry = self.entries.get(selected[0])
                if entry and entry["dir"]:
                    self.load_folder(reljoin(self.remote_dir, entry["name"]))

        def progress(self, title):
            last = [0.]
            def callback(current, total):
                now = time.monotonic()
                if now - last[0] > 0.2 or current == total:
                    self.events.put(("status", f"{title}: {fmt_bytes(current)} / {fmt_bytes(total)}"))
                    last[0] = now
            return callback

        def download_recursive(self, client, remote, dest):
            if Path(dest).is_symlink():
                raise ValueError(f"Refusing to follow a local folder link: {dest}")
            Path(dest).mkdir(parents=True, exist_ok=True)
            for item in client.list(remote):
                name = item["name"]
                child = reljoin(remote, name)
                local = Path(dest) / name
                if item["dir"]:
                    self.download_recursive(client, child, local)
                else:
                    client.download(child, local, self.progress("Downloading " + name))

        def download_selection(self):
            if not self.client:
                return messagebox.showerror("Transfer", "Connect to a host first")
            selected = [self.entries[id] for id in self.tree.selection()]
            if not selected:
                return
            dest = filedialog.askdirectory(title="Download into folder")
            if not dest:
                return
            existing = [x["name"] for x in selected if (Path(dest) / x["name"]).exists()]
            if existing:
                return messagebox.showerror("Download", "Already present (will not overwrite): " + ", ".join(existing))
            client, current = self.client, self.remote_dir
            def action():
                for entry in selected:
                    remote = reljoin(current, entry["name"])
                    local = Path(dest) / entry["name"]
                    if entry["dir"]:
                        self.download_recursive(client, remote, local)
                    else:
                        client.download(remote, local, self.progress("Downloading " + entry["name"]))
                return f"Downloaded {len(selected)} selected item(s) to {dest}"
            self.worker(action)

        def run_upload(self, files, folder=None):
            if not self.client:
                return messagebox.showerror("Transfer", "Connect to a host first")
            overwrite = self.overwrite.get()
            if overwrite and not messagebox.askyesno("Overwrite confirmation",
                                  "Overwrite any same-named files on the remote device?\n"
                                  "There is no undo for replaced files."):
                return
            client, current = self.client, self.remote_dir
            def action():
                if folder:
                    root = Path(folder)
                    destroot = reljoin(current, root.name)
                    client.mkdir(destroot)
                    count = 0
                    for here, dirs, names in os.walk(root, followlinks=False):
                        dirs[:] = [d for d in dirs if not (Path(here) / d).is_symlink()]
                        relative = Path(here).relative_to(root).as_posix()
                        remote_dir = destroot if relative == "." else destroot + "/" + relative
                        client.mkdir(remote_dir)
                        for name in names:
                            source = Path(here) / name
                            if not source.is_file() or source.is_symlink():
                                continue
                            client.upload(source, reljoin(remote_dir, name), overwrite,
                                          self.progress("Uploading " + name))
                            count += 1
                    return f"Uploaded folder: {count} files"
                for filename in files:
                    source = Path(filename)
                    client.upload(source, reljoin(current, source.name), overwrite,
                                  self.progress("Uploading " + source.name))
                return f"Uploaded {len(files)} file(s)"
            self.worker(action, refresh=True)

        def upload_files(self):
            files = filedialog.askopenfilenames(title="Select files to upload")
            if files:
                self.run_upload(files)

        def upload_folder(self):
            folder = filedialog.askdirectory(title="Choose folder to upload")
            if folder:
                self.run_upload([], folder=folder)

        def create_share(self):
            name = self.share_name.get().strip()
            path = self.host_dir.get()
            if not path.strip():
                return messagebox.showerror("Windows share", "Select a host folder in the first tab")
            if not messagebox.askyesno("Create native Windows share",
                   f"Share {path}\nas \\\\THIS-PC\\{name}\n\n"
                   "This grants change access to the currently signed-in Windows account.\n"
                   "An elevated LANBridge session is required. Proceed?"):
                return
            self.worker(lambda: windows_share(path, name))

        def check_smb(self):
            host = self.remote_host.get().strip()
            if host:
                self.worker(lambda: smb_port_test(host))
            else:
                messagebox.showerror("SMB", "Enter the storage machine's IP address")

        def map_drive(self):
            try:
                result = windows_map(self.remote_host.get().strip(), self.share_name.get().strip(),
                                     self.drive_letter.get().strip(), self.smb_username.get().strip(),
                                     self.smb_password.get())
                self.status.set("Mapped " + result)
                messagebox.showinfo("SMB drive ready", result)
            except Exception as e:
                messagebox.showerror("Map SMB drive", str(e))

        def open_linux_smb(self):
            host = self.remote_host.get().strip()
            share = self.share_name.get().strip()
            if not host or not share:
                return messagebox.showerror("SMB", "Host and share required")
            if not shutil.which("gio"):
                return messagebox.showerror("SMB", "gio is not installed. See README for mount.cifs usage")
            uri = f"smb://{urllib.parse.quote(host)}/{urllib.parse.quote(share)}"
            subprocess.Popen(["gio", "open", uri])

        def save_background_config(self):
            if self.host:
                return messagebox.showerror("Background host", "Stop interactive hosting before configuring a background service")
            root = self.host_dir.get().strip()
            if not root:
                return messagebox.showerror("Background host", "Choose the storage folder on the first tab")
            config = Path(self.service_config.get())
            replace = False
            if config.exists():
                replace = messagebox.askyesno("Rotate host key?",
                    "Configuration already exists. Replacing it will invalidate all previously shared access keys. Continue?")
                if not replace:
                    return
            try:
                file, data, fingerprint = configure_host(root, self.service_mode.get(), int(self.port.get()),
                                                          file=config, replace=replace)
                self.service_key.set(data["key"])
                self.service_fp.set(fingerprint)
                self.status.set("Saved persistent host settings to " + str(file))
                messagebox.showinfo("Background host", "Configuration saved. Copy the key and fingerprint to trusted clients. "
                                     "Install the service with Administrator privileges on Windows.")
            except Exception as e:
                messagebox.showerror("Background host", str(e))

        def service_action(self, action):
            def work():
                from service_support import manage
                return manage(action, Path(self.service_config.get()))
            self.worker(work)

        def close(self):
            if self.host:
                self.host.stop()
            self.root.destroy()

    Window().root.mainloop()


def service_config_file():
    if os.name == "nt":
        return Path(os.environ.get("PROGRAMDATA", "C:/ProgramData")) / "LANBridge" / "server.json"
    return app_dir() / "server.json"


def restrictive_write(file, data):
    file = Path(file)
    file.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".lanbridge-config-", dir=file.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            json.dump(data, out, indent=2)
            out.write("\n")
            out.flush()
            os.fsync(out.fileno())
        if os.name != "nt":
            os.chmod(name, 0o600)
        os.replace(name, file)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def windows_lock_service_state(path):
    """LocalService read access, Administrators/SYSTEM full; deny inheritance from Users."""
    if os.name != "nt":
        return
    folder = Path(path)
    # Use Windows SIDs so commands work across display-language variations.
    for target in [folder, *folder.glob("*")]:
        args = ["icacls.exe", str(target), "/inheritance:r", "/grant:r",
                "*S-1-5-19:(OI)(CI)RX" if target.is_dir() else "*S-1-5-19:R",
                "*S-1-5-18:(OI)(CI)F" if target.is_dir() else "*S-1-5-18:F",
                "*S-1-5-32-544:(OI)(CI)F" if target.is_dir() else "*S-1-5-32-544:F"]
        proc = subprocess.run(args, capture_output=True, text=True)
        if proc.returncode:
            raise PermissionError("Failed to protect service credentials; run in an elevated terminal: " + (proc.stderr or proc.stdout))


def configure_host(root, mode="backup", port=PORT, bind="0.0.0.0", networks=None,
                   max_clients=8, max_transfers=2, file=None, replace=False):
    global CONFIG_DIR
    file = Path(file or service_config_file()).expanduser().resolve()
    if file.exists() and not replace:
        raise FileExistsError(f"Configuration already exists: {file} (use --replace to rotate its access key)")
    root = Path(root).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Storage root must be a directory")
    if mode not in ("backup", "files", "readonly"):
        raise ValueError("Invalid storage mode")
    nets = list(networks or DEFAULT_NETWORKS)
    for network in nets:
        ipaddress.ip_network(network, strict=False)
    if not 1 <= int(port) <= 65535:
        raise ValueError("Invalid listening port")
    if not 1 <= int(max_transfers) <= int(max_clients) <= 128:
        raise ValueError("Connection limits must satisfy 1 <= transfers <= clients <= 128")
    CONFIG_DIR = file.parent
    certificate_files()
    data = {"version": VERSION, "root": str(root), "mode": mode, "port": int(port),
            "bind": bind, "allow_networks": nets, "max_clients": int(max_clients),
            "max_transfers": int(max_transfers), "key": secrets.token_hex(32).upper()}
    restrictive_write(file, data)
    if os.name == "nt" and file.parent == service_config_file().parent:
        windows_lock_service_state(file.parent)
    return file, data, certificate_files()[2]


def load_host_config(file):
    global CONFIG_DIR
    file = Path(file).expanduser().resolve(strict=True)
    data = json.loads(file.read_text(encoding="utf-8"))
    if data.get("version") != VERSION:
        raise ValueError("Unsupported service configuration version")
    if not re.fullmatch(r"[a-fA-F0-9]{64}", data.get("key", "")):
        raise ValueError("Invalid service access key")
    CONFIG_DIR = file.parent
    return data


def host_from_config(file):
    config = load_host_config(file)
    return Host(config["root"], config["port"], bind=config["bind"],
                key=config["key"], mode=config["mode"],
                allow_networks=config["allow_networks"],
                max_clients=config["max_clients"], max_transfers=config["max_transfers"])


def print_host_info(host, reveal=True):
    print("LANBridge host ready:", ", ".join(local_ipv4()), "TCP", host.port)
    print("Storage:", host.root, "| mode:", host.mode)
    print("SHA-256 fingerprint:", host.fingerprint)
    if reveal:
        print("Access key:", host.key, "(keep private)")
    print("Press Ctrl+C to stop foreground hosting.", flush=True)


def host_foreground(host, show_secret=True):
    stop_requested = threading.Event()
    previous = None
    if threading.current_thread() is threading.main_thread() and hasattr(signal, "SIGTERM"):
        previous = signal.getsignal(signal.SIGTERM)
        signal.signal(signal.SIGTERM, lambda *_: stop_requested.set())
    host.start()
    if show_secret:
        print_host_info(host, show_secret)
    else:
        print(f"LANBridge background host running on TCP {host.port} [{host.mode}]", flush=True)
    try:
        while not stop_requested.wait(0.5):
            pass
    except KeyboardInterrupt:
        pass
    finally:
        host.stop()
        if previous is not None:
            signal.signal(signal.SIGTERM, previous)


def add_client_flags(parser):
    parser.add_argument("--host", required=True, help="Host IPv4 address or hostname")
    parser.add_argument("--port", type=int, default=PORT)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--code", help="Access key (visible in shell history/process listing; prefer --code-file)")
    group.add_argument("--code-file", type=Path, help="File containing access key, one line")
    parser.add_argument("--fingerprint", required=True, help="SHA-256 from host console")


def make_client(args):
    if args.code_file:
        key = args.code_file.read_text(encoding="utf-8").strip()
    else:
        key = args.code or os.getenv("LANBRIDGE_CODE", "")
    if not key:
        raise ValueError("Specify --code-file, --code or the LANBRIDGE_CODE environment variable")
    return BridgeClient(args.host, args.port, key, args.fingerprint)


def unique_backup_label(source):
    # Collision-resistant, sortable snapshot directory. Never overwrite a snapshot.
    tag = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    suffix = secrets.token_hex(4)
    return "snapshots/" + tag + "-" + suffix + "/" + source.name


def push_directory(client, source, remote, overwrite=False, backup=False):
    source = Path(source).expanduser().resolve(strict=True)
    if not source.is_dir():
        raise ValueError("Source is not a directory")
    completed, total_bytes = 0, 0
    # One walk avoids recursively traversing symlink loops or external folders.
    for base, dirs, files in os.walk(source, followlinks=False):
        base_path = Path(base)
        dirs[:] = sorted(d for d in dirs if not (base_path / d).is_symlink())
        files = sorted(f for f in files if (base_path / f).is_file() and not (base_path / f).is_symlink())
        sub = base_path.relative_to(source).as_posix()
        prefix = remote + ("/" + sub if sub != "." else "")
        client.mkdir(prefix)
        for dirname in dirs:
            client.mkdir(prefix + "/" + dirname)
        for filename in files:
            local_file = base_path / filename
            remote_file = prefix + "/" + filename
            client.upload(local_file, remote_file, overwrite=overwrite and not backup,
                          preflight=not backup)
            completed += 1
            total_bytes += local_file.stat().st_size
            print(f"  {completed}: {remote_file} ({fmt_bytes(local_file.stat().st_size)})", flush=True)
    return completed, total_bytes


def pull_directory(client, remote, target):
    target = Path(target)
    if target.exists():
        raise FileExistsError(f"Local target already exists: {target}")
    target.mkdir(parents=True)
    completed = 0
    todo = [(remote.rstrip("/"), target)]
    try:
        while todo:
            rpath, folder = todo.pop()
            for entry in client.list(rpath):
                child = reljoin(rpath, entry["name"])
                if entry["dir"]:
                    sub = folder / entry["name"]
                    sub.mkdir()
                    todo.append((child, sub))
                else:
                    client.download(child, folder / entry["name"])
                    completed += 1
                    print(f"  {completed}: {child}", flush=True)
    except Exception:
        print("Download interrupted; completed files are retained; inspect target before restarting.", file=sys.stderr)
        raise
    return completed


def main():
    parser = argparse.ArgumentParser(description="LANBridge: encrypted LAN storage, backup, terminal and native services")
    cmds = parser.add_subparsers(dest="cmd")

    setup = cmds.add_parser("configure", help="Save persistent settings and strong access key for a background host")
    setup.add_argument("--dir", required=True, help="Existing folder to share")
    setup.add_argument("--mode", choices=("backup", "readonly", "files"), default="backup")
    setup.add_argument("--port", type=int, default=PORT)
    setup.add_argument("--bind", default="0.0.0.0", help="Listening network interface")
    setup.add_argument("--allow-network", action="append", dest="networks", help="Allow CIDR (repeatable; defaults to private IPv4 ranges)")
    setup.add_argument("--max-clients", type=int, default=8)
    setup.add_argument("--max-transfers", type=int, default=2)
    setup.add_argument("--config", type=Path, help="Config path; Windows service default is ProgramData/LANBridge/server.json")
    setup.add_argument("--replace", action="store_true", help="Replace prior config AND rotate access key")

    show = cmds.add_parser("show-config", help="Inspect persistent host identity and connection settings")
    show.add_argument("--config", type=Path)
    show.add_argument("--reveal-key", action="store_true", help="Display private access key")

    serve = cmds.add_parser("serve", help="Foreground terminal-only host")
    group = serve.add_mutually_exclusive_group(required=True)
    group.add_argument("--dir", help="Folder for temporary host (key rotates each launch)")
    group.add_argument("--config", type=Path, help="Use persistent host configuration")
    serve.add_argument("--port", type=int, default=PORT)
    serve.add_argument("--bind", default="0.0.0.0")
    serve.add_argument("--mode", choices=("readonly", "files", "backup"), default="readonly")
    serve.add_argument("--allow-uploads", action="store_true", help="Legacy alias of --mode files")

    service = cmds.add_parser("service", help="Install/manage background hosting service")
    service.add_argument("action", choices=("install", "start", "stop", "restart", "status", "remove", "run"))
    service.add_argument("--config", type=Path, help="Persistent config path")

    for command in ("info", "ls", "pull", "push", "backup", "pull-tree", "push-tree"):
        sub = cmds.add_parser(command)
        add_client_flags(sub)
        if command == "ls":
            sub.add_argument("remote", nargs="?", default="")
        elif command in ("pull", "push", "push-tree", "pull-tree"):
            sub.add_argument("source")
            sub.add_argument("destination")
        elif command == "backup":
            sub.add_argument("source")
        if command in ("push", "push-tree"):
            sub.add_argument("--overwrite", action="store_true")

    args = parser.parse_args()
    if args.cmd is None:
        gui()
    elif args.cmd == "configure":
        file, data, fp = configure_host(args.dir, args.mode, args.port, args.bind,
                                       args.networks, args.max_clients, args.max_transfers,
                                       args.config, args.replace)
        print("Configured:", file)
        print("Root:", data["root"], "| mode:", data["mode"])
        print("Fingerprint:", fp)
        print("Private access key:", data["key"])
        print("Keep this key off shared drives and shell command histories.")
        if os.name == "nt":
            print("Native Windows service uses LocalService. Grant that account Modify permission on the chosen storage folder.")
    elif args.cmd == "show-config":
        config = Path(args.config or service_config_file())
        data = load_host_config(config)
        fp = certificate_files()[2]
        for k, v in data.items():
            if k != "key" or args.reveal_key:
                print(f"{k}: {v}")
        print("fingerprint:", fp)
        if not args.reveal_key:
            print("Access key hidden; pass --reveal-key from a trusted local terminal to show it.")
    elif args.cmd == "serve":
        host = host_from_config(args.config) if args.config else Host(
            args.dir, args.port, writable=args.allow_uploads, bind=args.bind,
            mode="files" if args.allow_uploads else args.mode)
        host_foreground(host)
    elif args.cmd == "service":
        from service_support import manage, run_windows_service
        config = Path(args.config or service_config_file()).expanduser().resolve()
        if args.action == "run":
            if os.name == "nt":
                run_windows_service(lambda: host_from_config(config))
            else:
                host_foreground(host_from_config(config), show_secret=False)
        else:
            if args.action == "install":
                data = load_host_config(config)
                if os.name == "nt" and config.parent != service_config_file().parent:
                    raise ValueError("Windows service configuration must be in ProgramData/LANBridge")
                print("Installing", data["mode"], "host for", data["root"])
            print(manage(args.action, config))
    else:
        client = make_client(args)
        if args.cmd == "info":
            info = client.info()
            print(f"Host: {info['host']} | mode: {info['mode']} | total: {fmt_bytes(info['total'])} | free: {fmt_bytes(info['free'])}")
        elif args.cmd == "ls":
            for entry in client.list(args.remote):
                print("DIR " if entry["dir"] else "FILE", fmt_bytes(entry["size"]), entry["name"])
        elif args.cmd == "pull":
            client.download(args.source, args.destination)
            print("Downloaded to", args.destination)
        elif args.cmd == "push":
            result = client.upload(args.source, args.destination, args.overwrite)
            print("Uploaded", args.destination, "SHA-256", result['sha256'])
        elif args.cmd == "push-tree":
            files, count = push_directory(client, args.source, args.destination, overwrite=args.overwrite)
            print(f"Uploaded {files} files ({fmt_bytes(count)})")
        elif args.cmd == "pull-tree":
            count = pull_directory(client, args.source, args.destination)
            print(f"Downloaded {count} files")
        elif args.cmd == "backup":
            source = Path(args.source).expanduser().resolve(strict=True)
            name = unique_backup_label(source)
            if source.is_dir():
                files, size = push_directory(client, source, name, backup=True)
                print(f"Immutable snapshot uploaded: {name} ({files} files, {fmt_bytes(size)})")
            else:
                client.mkdir(name.rsplit("/", 1)[0])
                result = client.upload(source, name, preflight=False)
                print(f"Backup uploaded: {name} SHA-256 {result['sha256']}")
            print("Existing backups were not modified.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError, ssl.SSLError) as error:
        print(f"LANBridge: {error}", file=sys.stderr)
        sys.exit(1)
