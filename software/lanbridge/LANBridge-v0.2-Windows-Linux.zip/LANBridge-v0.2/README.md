# LANBridge v0.2 — native GUI, terminal-only LAN storage, protected backup service

**Windows 10, Windows 11 and Linux | direct IP | TLS | no cloud, no browser or Chromium.**

LANBridge does two different jobs:

1. **Encrypted file/backup transfer independent of Windows discovery and SMB**, using TCP **8537**. Windows and Linux can both host or connect. Source needs Python **3.10+** and the sole third-party dependency `cryptography`. GUI uses built-in Tkinter. Packaged executable builds are described below.
2. **Native SMB drive mapping** (`Z:` in Windows, CIFS mount on Linux) for genuinely mounted, live network storage. SMB is an independent Windows/Samba service on TCP **445**, not a FUSE driver implemented by LANBridge.

Use **Backup mode** for an aging Windows 10 machine: it accepts *new* timestamped snapshots without offering deletion or overwrite operations. Use **Files mode** only for folders where remote file replacement is intentional, and **Read-only mode** for browse/download only.

## Fastest setup: Windows 10 backup storage host → Windows 11 client

On the **Windows 10 storage host**:

1. Extract the folder permanently (don't run a background service out of Downloads, removable media, or a temporary folder). Choose/create a dedicated storage directory such as `D:\LANBridgeBackups` — **not** your whole drive.
2. Install Python 3.10+ if running source, then `py -3 -m pip install -r requirements.txt`. Alternatively, use the compiled Windows CLI build produced by the included GitHub Actions workflow (not bundled in this source archive).
3. In an **Administrator PowerShell/terminal**, run `Setup-Windows-BackupHost.ps1` (or launch `Run-Windows-BackupHost-Setup.bat` as Administrator). This creates a protected persistent configuration, grants `LocalService` storage-folder permissions, installs a native **Windows service**, offers a **Private/LocalSubnet** firewall rule, and starts hosting.
4. Copy the displayed **64-character access key** and **SHA-256 host fingerprint** to the Windows 11 client *through a trusted method*. They are credentials; don't publish them or store them inside the shared backup folder.
5. The Windows 10 console can close; the service keeps running at boot. Check `sc.exe query LANBridgeStorage` or Windows Services.

On the **Windows 11 client**, extract LANBridge, run `Run-Windows.bat` for the GUI, or run the console:

```powershell
# File containing ONLY the 64-character access key, accessible only to this user:
# (Use the real IPv4 and fingerprint from the Windows 10 computer.)
py -3 src\lanbridge.py info --host 192.168.1.50 --code-file .\host-key.txt --fingerprint HOST_SHA256
py -3 src\lanbridge.py backup --host 192.168.1.50 --code-file .\host-key.txt --fingerprint HOST_SHA256 "C:\ImportantFiles"
py -3 src\lanbridge.py ls --host 192.168.1.50 --code-file .\host-key.txt --fingerprint HOST_SHA256 snapshots
```

In the **GUI**, use the **Browse / Transfer** tab to connect via IP / port / access key and compare the displayed fingerprint against the Windows 10 host. The **Background host** tab saves persistent configuration and offers service controls, but Windows service setup requires Administrator permissions and explicit LocalService access to the storage directory. The PowerShell assistant configures those requirements together.

**Do not forward TCP 8537 or 445 from the internet.** Keep inbound rules limited to your Private LAN and authorized clients.

## Linux desktop and background host

```bash
sudo apt install python3-tk python3-venv  # Debian/Ubuntu, adapt for your distro
./run-linux.sh                          # Tk GUI

# First-time persistent setup: the storage folder must exist
./run-linux.sh configure --dir /mnt/data/backups --mode backup
./run-linux.sh service install         # systemd --user, enables AND starts it
./run-linux.sh service status
./run-linux.sh service stop
./run-linux.sh service start
./run-linux.sh service remove
```

Linux background service uses **systemd user services**, not root. It normally starts when your user session starts. For boot-time service availability **before login**, an administrator may run `sudo loginctl enable-linger YOUR_USERNAME`. The program must remain at its installed path, and the storage volume must be mounted before backup uploads are sent. The service is configured to restart on failures.

To operate entirely in the terminal without installing a service:

```bash
./run-linux.sh serve --dir /mnt/data/backups --mode backup --bind 0.0.0.0
# Or restart using the same persistent identity/access key each time:
./run-linux.sh serve --config "$HOME/.lanbridge/server.json"
```

The temporary foreground `serve --dir` command rotates its access key each start. `configure` creates a **256-bit persistent key** and per-host TLS certificate for unattended hosting. Default listener is `0.0.0.0:8537`, but actual access is restricted to **private/local IPv4 subnets** unless customized, and an OS firewall rule is still needed. To restrict further, specify one or more `--allow-network 192.168.1.0/24` arguments when configuring.

## Terminal commands

Each client command takes `--host IP`, `--fingerprint SHA256`, and either `--code-file FILE`, `LANBRIDGE_CODE` environment variable, or legacy `--code KEY`. Prefer the file; passing secrets directly on a command line exposes them through process listings and shell history.

| Command | Purpose |
| --- | --- |
| `info` | Remote name, mode, disk capacity/free space |
| `ls [remote]` | Remote directory listing |
| `pull REMOTE LOCAL` | Download one file, refusing local overwrite |
| `push LOCAL REMOTE [--overwrite]` | Upload a file; SHA-256 check of streamed contents |
| `push-tree LOCAL_DIR REMOTE_DIR` | Upload whole folder tree, skip symlinks |
| `pull-tree REMOTE_DIR LOCAL_DIR` | Download tree into a **new** local folder |
| `backup LOCAL_PATH` | Timestamped unique remote `snapshots/...` path, never overwrite |
| `configure --dir DIR --mode backup` | Generate restricted host config and strong persistent key |
| `show-config [--reveal-key]` | Inspect local host settings/certificate identity |
| `serve --config CONFIG` | Run configured host in a terminal (Ctrl+C to stop) |
| `service install/start/stop/restart/status/remove` | Manage Windows service or Linux systemd user service |

`configure` supports `--mode backup|files|readonly`, `--port`, `--bind`, repeatable `--allow-network CIDR`, `--max-clients 8`, `--max-transfers 2`, `--config`, `--replace`. Replacing a configuration *rotates the access key*; prior client key files must be updated. Service configuration defaults to `%PROGRAMDATA%\LANBridge\server.json` on Windows or `~/.lanbridge/server.json` on Linux.

Note that the GUI and terminal host are two ways to run **the same program**, not separate protocols. Desktop windows do not need to remain open when the independently installed background host runs. Avoid launching two hosts on the same TCP port.

## Mapping shared folders as actual Windows drives

The independent LANBridge HTTPS protocol is designed for **transferring files**, not a mounted virtual filesystem. If you want `Z:` available to Windows programs, use an existing SMB share: on the Windows storage PC, share a *different, carefully permissioned* live-storage folder; on the client, enter `\\192.168.1.50\Storage` or use the **Map network drive** tab. The package also contains `Run-Windows-QuickSMB.bat`, a native PowerShell SMB helper.

Linux clients can mount `//192.168.1.50/Storage` using `cifs-utils` or browse via `gio`. SMB must be permitted on TCP 445 from the intended clients. Never enable SMB1 or anonymous guest access simply to make discovery work.

**Do not expose protected backup snapshots through a separate writable SMB share.** That would bypass LANBridge's no-overwrite protection.

## Security and capacity

- TLS 1.2+ with SHA-256 certificate fingerprint comparison/pinning by the GUI; terminal clients **require an explicit fingerprint**. Clients check host identity *before sending the access key*.
- Service configuration key is 256 bits; temporary foreground/GUI sessions use a new 128-bit code. Host config and private key are stored in the local service state directory. Linux permissions are restricted to the user; Windows service setup additionally configures restrictive ACLs for `LocalService`, `SYSTEM` and Administrators.
- Default allowed source networks are loopback, RFC1918 private IPv4 and link-local IPv4. To limit to your actual subnet, use `configure --allow-network 192.168.1.0/24` and apply a similarly restrictive host firewall rule.
- Six failed authentications within 60 seconds trigger a temporary per-IP lockout. Default concurrency is **8 connections / 2 active transfers**, configurable. TLS handshakes happen in bounded workers so slow clients don't block the entire listening socket.
- Backup uploads are streamed to a temporary file, SHA-256 hashed, `fsync`ed, then published without overwriting an existing file. On Linux the destination filesystem must support hardlinks for atomic no-clobber backup publication; Windows uses non-overwriting rename.
- No delete operation, no remote shell, no RDP, no guest mode, no remote execution, no internet exposure or telemetry.
- **Limits:** The backup protection applies only through the LANBridge API; users or other services with filesystem write access can still change files. It is not a substitute for independent offline backups/snapshots. Per-device credentials/revocation, quotas, automatic backup scheduling, resumable uploads, and comprehensive junction/reparse-point race hardening are **not yet implemented**. A paired client can deliberately fill the designated storage folder. Keep the Windows 10 host updated where possible and restrict its role and network access.

## Build genuine desktop/terminal executables

The included `.github/workflows/build.yml` builds **two separate, native packaged Python executables** for Windows and Linux using PyInstaller on each operating system: `LANBridge-GUI` (Tkinter GUI) and `LANBridge-CLI` (terminal + service). It uses `--onedir` for faster startup; neither program bundles Chromium. A **Windows EXE cannot be produced/validated on this Linux development machine**. The source archive includes the workflow, not prebuilt binaries. GitHub Actions must run to obtain OS-specific artifacts.

## Test

```bash
python -m unittest discover -s tests -v
```

Tested on Linux loopback for transfer, browsing, overwrite protection, persistent configuration, hostname pinning, network restrictions, throttling, directory backups and service unit generation. A Linux GUI smoke test is also part of packaging validation. Actual Windows 10/11 service installation, Windows ACLs/SCM integration, SMB mapping, and native Windows executables require tests on real Windows hosts.
