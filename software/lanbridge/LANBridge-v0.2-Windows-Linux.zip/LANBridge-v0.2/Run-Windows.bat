@echo off
cd /d "%~dp0"
if exist "LANBridge-GUI.exe" ("LANBridge-GUI.exe" & exit /b)
if exist "LANBridge-GUI\LANBridge-GUI.exe" ("LANBridge-GUI\LANBridge-GUI.exe" & exit /b)
if exist "dist\LANBridge-GUI\LANBridge-GUI.exe" ("dist\LANBridge-GUI\LANBridge-GUI.exe" & exit /b)
where py >nul 2>&1
if errorlevel 1 (
    echo Python 3.10+ is required to run the source version.
    echo Obtain Python from python.org, or use a prebuilt LANBridge EXE.
    pause
    exit /b 1
)
py -3 -c "import cryptography" >nul 2>&1
if errorlevel 1 (
    echo Installing one required TLS library...
    py -3 -m pip install -r requirements.txt || (pause & exit /b 1)
)
py -3 src\lanbridge.py
if errorlevel 1 pause
