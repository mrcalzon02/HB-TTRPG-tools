#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
.venv/bin/python -c 'import cryptography' 2>/dev/null || .venv/bin/python -m pip install -r requirements.txt
exec .venv/bin/python src/lanbridge.py "$@"
