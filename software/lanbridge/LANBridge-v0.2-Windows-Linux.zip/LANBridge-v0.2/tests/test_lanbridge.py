import importlib.util
import hashlib
import sys
import os
from pathlib import Path
import ssl
import tempfile
import threading
import unittest

SRC = Path(__file__).resolve().parents[1] / 'src' / 'lanbridge.py'
spec = importlib.util.spec_from_file_location('lanbridge', SRC)
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
sys.path.insert(0, str(SRC.parent))
from service_support import systemd_unit, command_to_run


class TestBridge(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = Path(self.tmp.name)
        bridge.CONFIG_DIR = self.home / 'config'
        self.root = self.home / 'shared'
        self.root.mkdir()
        (self.root / 'exists.txt').write_text('existing data', encoding='utf-8')
        (self.root / 'sub').mkdir()
        (self.root / 'sub' / 'deep.txt').write_text('deep', encoding='utf-8')
        self.host = bridge.Host(self.root, port=0, bind='127.0.0.1', writable=True)
        self.host.start()
        self.client = bridge.BridgeClient('127.0.0.1', self.host.port, self.host.key, self.host.fingerprint)

    def tearDown(self):
        self.host.stop()
        self.tmp.cleanup()

    def test_info_listing_and_empty_folder(self):
        info = self.client.info()
        self.assertEqual(info['version'], 2)
        self.assertGreaterEqual(info['free'], 0)
        items = self.client.list()
        self.assertEqual([i['name'] for i in items], ['sub', 'exists.txt'])
        self.assertEqual([i['name'] for i in self.client.list('sub')], ['deep.txt'])
        self.client.mkdir('empty/new')
        self.assertTrue((self.root / 'empty' / 'new').is_dir())

    def test_upload_download_binary_and_overwrite(self):
        src = self.home / 'local.bin'
        src.write_bytes(os.urandom(2_000_000))
        self.client.upload(src, 'nested/local.bin')
        self.assertEqual((self.root / 'nested' / 'local.bin').read_bytes(), src.read_bytes())
        with self.assertRaises(RuntimeError):
            self.client.upload(src, 'nested/local.bin')
        self.client.upload(src, 'nested/local.bin', overwrite=True)
        dest = self.home / 'download.bin'
        self.client.download('nested/local.bin', dest)
        self.assertEqual(dest.read_bytes(), src.read_bytes())
        with self.assertRaises(FileExistsError):
            self.client.download('nested/local.bin', dest)

    def test_no_remote_traversal(self):
        for bad in ('../secret', '/etc/passwd', 'foo/../bar', 'C:/windows', 'foo\\bar', '%2e%2e'):
            # URL percent literals are safe filenames, but check_relative itself rejects real traversal.
            if bad == '%2e%2e':
                continue
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    bridge.checked_path(self.root, bad)
        with self.assertRaises(RuntimeError):
            self.client.list('../')
        with self.assertRaises(RuntimeError):
            self.client.mkdir('../escape')
        if hasattr(os, 'symlink'):
            outside = self.home / 'outside'
            outside.mkdir()
            try:
                (self.root / 'link').symlink_to(outside, target_is_directory=True)
            except OSError:
                return
            self.assertNotIn('link', [e['name'] for e in self.client.list()])
            with self.assertRaises(RuntimeError):
                self.client.mkdir('link/hack')
            self.assertFalse((outside / 'hack').exists())

    def test_bad_code_and_wrong_certificate(self):
        bad = bridge.BridgeClient('127.0.0.1', self.host.port, 'WRONG', self.host.fingerprint)
        with self.assertRaises(RuntimeError):
            bad.info()
        wrong = bridge.BridgeClient('127.0.0.1', self.host.port, self.host.key, 'A' * 64)
        with self.assertRaises(ssl.SSLError):
            wrong.info()

    def test_read_only_host(self):
        self.host.stop()
        self.host = bridge.Host(self.root, port=0, bind='127.0.0.1', writable=False)
        self.host.start()
        c = bridge.BridgeClient('127.0.0.1', self.host.port, self.host.key, self.host.fingerprint)
        with self.assertRaises(RuntimeError):
            c.mkdir('blocked')
        with self.assertRaises(RuntimeError):
            c.upload(self.root / 'exists.txt', 'blocked.txt')

    def test_protected_backup_mode_never_overwrites(self):
        self.host.stop()
        self.host = bridge.Host(self.root, port=0, bind='127.0.0.1', mode='backup')
        self.host.start()
        c = bridge.BridgeClient('127.0.0.1', self.host.port, self.host.key, self.host.fingerprint)
        source = self.home / 'new.txt'
        source.write_text('unique backup data')
        result = c.upload(source, 'snapshots/2026/new.txt', preflight=False)
        self.assertEqual(result['sha256'], hashlib.sha256(source.read_bytes()).hexdigest())
        with self.assertRaises(RuntimeError):
            c.upload(source, 'snapshots/2026/new.txt', overwrite=True)
        self.assertEqual((self.root / 'snapshots/2026/new.txt').read_text(), 'unique backup data')

    def test_persistent_config_preserves_key_and_identity(self):
        self.host.stop()
        cfg = self.home / 'state' / 'server.json'
        file, data, fp = bridge.configure_host(self.root, mode='backup', port=8542,
                                               file=cfg, networks=['127.0.0.0/8'])
        self.assertEqual(file, cfg)
        self.assertEqual(len(data['key']), 64)
        self.assertEqual(data['mode'], 'backup')
        h = bridge.host_from_config(file)
        self.assertEqual(h.key, data['key'])
        self.assertEqual(h.fingerprint, fp)
        self.assertEqual(h.mode, 'backup')
        self.assertEqual(h.port, 8542)
        h.server.server_close()
        with self.assertRaises(FileExistsError):
            bridge.configure_host(self.root, file=cfg)
        _, changed, newer_fp = bridge.configure_host(self.root, file=cfg, replace=True)
        self.assertNotEqual(changed['key'], data['key'])
        self.assertEqual(newer_fp, fp)

    def test_cidr_restriction(self):
        self.host.stop()
        self.host = bridge.Host(self.root, port=0, bind='127.0.0.1',
                                mode='backup', allow_networks=['10.0.0.0/8'])
        self.host.start()
        c = bridge.BridgeClient('127.0.0.1', self.host.port, self.host.key, self.host.fingerprint)
        with self.assertRaisesRegex(RuntimeError, 'not authorized'):
            c.info()

    def test_login_throttling(self):
        wrong = bridge.BridgeClient('127.0.0.1', self.host.port, 'NO', self.host.fingerprint)
        for _ in range(6):
            with self.assertRaises(RuntimeError):
                wrong.info()
        with self.assertRaisesRegex(RuntimeError, 'Too many failed logins'):
            self.client.info()

    def test_directory_backup_skips_symlinks(self):
        self.host.stop()
        self.host = bridge.Host(self.root, port=0, bind='127.0.0.1', mode='backup')
        self.host.start()
        c = bridge.BridgeClient('127.0.0.1', self.host.port, self.host.key, self.host.fingerprint)
        source = self.home / 'photos'
        source.mkdir()
        (source / 'hi.txt').write_text('hello')
        (source / 'folder').mkdir()
        (source / 'folder' / 'small.bin').write_bytes(b'1234')
        (source / 'empty').mkdir()
        if hasattr(os, 'symlink'):
            try:
                (source / 'bad').symlink_to(self.root, target_is_directory=True)
            except OSError:
                pass
        count, size = bridge.push_directory(c, source, 'snapshots/test/photos', backup=True)
        self.assertEqual((count, size), (2, 9))
        self.assertFalse((self.root / 'snapshots/test/photos/bad').exists())
        self.assertTrue((self.root / 'snapshots/test/photos/empty').is_dir())
        self.assertEqual((self.root / 'snapshots/test/photos/folder/small.bin').read_bytes(), b'1234')

    def test_systemd_unit_no_shell_interpolation(self):
        unit = systemd_unit(self.home / 'config with spaces' / 'server.json')
        self.assertIn('ExecStart=', unit)
        self.assertIn('Restart=on-failure', unit)
        self.assertIn('service', unit)
        self.assertIn('server.json', unit)
        self.assertIn('NoNewPrivileges=true', unit)



if __name__ == '__main__':
    unittest.main()
