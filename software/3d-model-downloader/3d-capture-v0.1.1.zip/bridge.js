(() => {
  "use strict";
  const channel="3d-capture-v1", pending=new Map(); let serial=0;
  const send=action=>window.postMessage({channel,direction:"to-page",action},"*");
  function ask(action) {
    return new Promise((resolve,reject)=>{
      const requestId=crypto.randomUUID()+"-"+(++serial);
      const timer=setTimeout(()=>{pending.delete(requestId);reject(Error("Viewer capture did not respond."));},20000);
      pending.set(requestId,{resolve,reject,timer});
      window.postMessage({channel,direction:"to-page",action,requestId},"*");
    });
  }
  addEventListener("message",event=>{
    if(event.source!==window || event.data?.channel!==channel || event.data.direction!=="from-page")return;
    const p=pending.get(event.data.requestId); if(!p)return;
    pending.delete(event.data.requestId);clearTimeout(p.timer);
    // Page data is untrusted. It can only answer explicit status/export requests.
    p.resolve(event.data.data);
  });
  browser.runtime.onMessage.addListener(message=>{
    if(message?.scope!=="capture-bridge")return;
    if(["enable","disable","pause","clear"].includes(message.action)) {send(message.action);return Promise.resolve({ok:true});}
    if(["status","export"].includes(message.action))return ask(message.action);
  });
  browser.runtime.sendMessage({action:"frame-state"}).then(state=>send(state.active?"enable":"disable")).catch(()=>send("disable"));
})();
