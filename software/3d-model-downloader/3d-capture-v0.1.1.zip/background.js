"use strict";
const sessions=new Map(), inflight=new Map(), downloadUrls=new Map();
const MAX_FILE=128*1024*1024, MAX_SESSION=384*1024*1024;
const newSession=()=>({active:false,assets:new Map(),bytes:0,reserved:0,warnings:new Set(),started:new Date().toISOString()});
const stateFor=id=>{if(!sessions.has(id))sessions.set(id,newSession());return sessions.get(id);};
function warning(s,text){if(s.warnings.size<50)s.warnings.add(text);}
function badge(id,s){browser.browserAction.setBadgeText({tabId:id,text:s.assets.size?String(s.assets.size):s.active?"ON":""}).catch(()=>{});browser.browserAction.setBadgeBackgroundColor({tabId:id,color:s.active?"#15795f":"#59636d"}).catch(()=>{});}
async function frames(tabId,action) {
  const list=await browser.webNavigation.getAllFrames({tabId});
  return Promise.all((list||[]).map(async frame=>{
    try{return {frameId:frame.frameId,data:await browser.tabs.sendMessage(tabId,{scope:"capture-bridge",action},{frameId:frame.frameId})};}
    catch(e){return {frameId:frame.frameId,error:e.message};}
  }));
}
function addAsset(tabId,s,url,mime,kind,data) {
  if(sessions.get(tabId)!==s)return;
  const previous=s.assets.get(url),size=data.byteLength;
  if(s.bytes-(previous?.size||0)+size>MAX_SESSION || (!previous&&s.assets.size>=1500)){warning(s,"Original-file limit reached (384 MB / 1,500 files per tab). Export, then clear to continue.");return;}
  let path=CaptureLib.assetPath(url,kind);
  for(const a of s.assets.values())if(a.url!==url&&a.path.toLowerCase()===path.toLowerCase()) {path=path.replace(/(\.[^/.]+)?$/,`_${CaptureLib.hash(url)}$1`);break;}
  s.assets.set(url,{url,mime,kind,path,size,blob:new Blob([data],{type:mime||"application/octet-stream"})});
  s.bytes+=size-(previous?.size||0);badge(tabId,s);
}
function release(request) {
  if(request.released)return;request.released=true;
  request.session.reserved-=request.size;request.chunks=[];inflight.delete(request.id);
}
browser.webRequest.onBeforeRequest.addListener(details=>{
  const s=sessions.get(details.tabId);
  if(!s?.active || !/^https?:/.test(details.url))return {};
  const known=CaptureLib.classify(details.url);
  if(!known&&!['xmlhttprequest','other','image'].includes(details.type))return {};
  let filter;try{filter=browser.webRequest.filterResponseData(details.requestId);}catch(e){warning(s,"A response could not be captured: "+e.message);return {};}
  const r={id:details.requestId,session:s,tabId:details.tabId,url:details.url,mime:"",status:200,chunks:[],size:0,released:false};
  inflight.set(r.id,r);
  filter.ondata=event=>{
    // Forward every byte unchanged before doing capture work.
    filter.write(event.data);
    if(!s.active || sessions.get(r.tabId)!==s || r.status<200 || r.status>=300 || r.status===206 || r.size+event.data.byteLength>MAX_FILE || s.bytes+s.reserved+event.data.byteLength>MAX_SESSION) {
      if(r.status===206)warning(s,"Partial HTTP responses were skipped; use WebGL export or a viewer that loads complete files.");
      else if(s.active&&r.status>=200&&r.status<300)warning(s,"A response exceeded capture memory limits.");
      release(r);filter.disconnect();return;
    }
    const copy=new Uint8Array(event.data).slice();r.chunks.push(copy);r.size+=copy.length;s.reserved+=copy.length;
  };
  filter.onstop=()=>{
    filter.close();
    if(r.released)return;
    try {
      if(s.active&&r.status>=200&&r.status<300&&r.status!==206&&r.size) {
        const prefix=new Uint8Array(Math.min(65536,r.size));let off=0;
        for(const chunk of r.chunks){const part=chunk.subarray(0,prefix.length-off);prefix.set(part,off);off+=part.length;if(off===prefix.length)break;}
        const kind=CaptureLib.classify(r.url,r.mime,prefix);
        if(kind) {const data=new Uint8Array(r.size);off=0;for(const chunk of r.chunks){data.set(chunk,off);off+=chunk.length;}addAsset(r.tabId,s,r.url,r.mime,kind,data);}
      }
    } catch(e){warning(s,"A resource could not be stored: "+e.message);}finally{release(r);}
  };
  filter.onerror=()=>{warning(s,"A response stream failed: "+filter.error);release(r);};
  return {};
},{urls:["http://*/*","https://*/*"]},["blocking"]);
browser.webRequest.onHeadersReceived.addListener(details=>{
  const r=inflight.get(details.requestId);if(!r)return {};
  r.status=details.statusCode;r.mime=details.responseHeaders?.find(h=>h.name.toLowerCase()==="content-type")?.value?.split(";")[0]||"";
  return {};
},{urls:["http://*/*","https://*/*"]},["blocking","responseHeaders"]);
browser.tabs.onRemoved.addListener(id=>sessions.delete(id));
async function save(blob,filename) {
  const url=URL.createObjectURL(blob);
  try {const id=await browser.downloads.download({url,filename,saveAs:true});downloadUrls.set(id,url);return id;}
  catch(e){URL.revokeObjectURL(url);throw e;}
}
browser.downloads.onChanged.addListener(delta=>{
  if(delta.state?.current==="complete" || delta.state?.current==="interrupted") {
    const url=downloadUrls.get(delta.id);if(url)URL.revokeObjectURL(url);downloadUrls.delete(delta.id);
  }
});
async function bundle(s) {
  const assets=[...s.assets.values()], byUrl=new Map(assets.map(a=>[a.url,a.path])), entries=[],missing=[];
  for(const a of assets) {
    let data=new Uint8Array(await a.blob.arrayBuffer());
    if(a.kind==="gltf")try {
      const json=JSON.parse(new TextDecoder().decode(data));
      for(const ref of [...(json.buffers||[]),...(json.images||[])]) {
        if(!ref.uri || ref.uri.startsWith("data:"))continue;
        const uri=new URL(ref.uri,a.url).href,path=byUrl.get(uri);
        if(path)ref.uri=CaptureLib.relative(a.path,path);else missing.push({model:a.path,uri});
      }
      data=new TextEncoder().encode(JSON.stringify(json,null,2));
    }catch(e){missing.push({model:a.path,error:e.message});}
    entries.push({name:a.path,data});
  }
  entries.push({name:"capture.json",data:JSON.stringify({created:s.started,assets:assets.map(({blob,...a})=>a),missing,warnings:[...s.warnings]},null,2)});
  entries.push({name:"READ-ME.txt",data:"3D Capture\n\nExtract the entire ZIP before opening models. glTF buffer/image references are rewritten to captured files. Other formats are saved unchanged. capture.json lists missing glTF resources and source URLs (which can include private signed links).\n\nTextures and generic binary support files can include unrelated page resources. Original-file capture is preferred for materials, animation, skinning, scene transforms, and compressed geometry.\n"});
  return CaptureLib.zip(entries);
}
browser.runtime.onMessage.addListener((message,sender)=>{
  if(message?.action==="frame-state"&&sender.tab)return Promise.resolve({active:!!sessions.get(sender.tab.id)?.active});
  // Commands that reload pages or save files are accepted only from extension pages.
  if(sender.tab && !sender.url?.startsWith(browser.runtime.getURL("")))return;
  if(!sender.url?.startsWith(browser.runtime.getURL("")))return;
  return (async()=>{
    const tabId=message.tabId;if(!Number.isInteger(tabId))throw Error("Select a normal viewer tab.");
    const s=stateFor(tabId);
    if(message.action==="status")return {active:s.active,bytes:s.bytes,pending:[...inflight.values()].filter(r=>r.tabId===tabId&&!r.released).length,warnings:[...s.warnings],assets:[...s.assets.values()].map(({blob,...a})=>a)};
    if(message.action==="start") {
      const tab=await browser.tabs.get(tabId);if(!/^https?:/.test(tab.url||""))throw Error("Open a viewer on an HTTP or HTTPS page first.");
      s.active=true;badge(tabId,s);await frames(tabId,"enable");await browser.tabs.reload(tabId,{bypassCache:true});return {ok:true};
    }
    if(message.action==="pause") {s.active=false;badge(tabId,s);await frames(tabId,"pause");return {ok:true};}
    if(message.action==="clear") {const next=newSession();next.active=s.active;sessions.set(tabId,next);badge(tabId,next);await frames(tabId,"clear");return {ok:true};}
    if(message.action==="mesh-status")return frames(tabId,"status");
    if(message.action==="mesh-export") {
      const results=await frames(tabId,"export"),entries=[],notes=[];
      for(const r of results) {
        const d=r.data;
        if(d&&typeof d.text==="string"&&d.text.length<=32*1024*1024&&d.exported>0)entries.push({name:`frame-${r.frameId}.obj`,data:d.text});
        notes.push({frameId:r.frameId,exported:d?.exported||0,warnings:d?.warnings||[],error:r.error});
      }
      if(!entries.length)throw Error("No supported meshes recorded. Start capture and reload, then rotate/play the viewer. WebGPU, worker rendering and unrecognized position shaders are unsupported.");
      entries.push({name:"export-notes.json",data:JSON.stringify(notes,null,2)});
      await save(CaptureLib.zip(entries),"3D-Capture/webgl-meshes.zip");return {ok:true};
    }
    if(message.action==="download") {const a=s.assets.get(message.url);if(!a)throw Error("File no longer available.");await save(a.blob,"3D-Capture/"+a.path);return {ok:true};}
    if(message.action==="bundle") {if(!s.assets.size)throw Error("No files recorded yet.");await save(await bundle(s),"3D-Capture/original-assets.zip");return {ok:true};}
    throw Error("Unknown action.");
  })().catch(e=>({error:e.message}));
});
