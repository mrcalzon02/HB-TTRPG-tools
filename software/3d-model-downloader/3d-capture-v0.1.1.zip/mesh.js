/* Convert captured attribute/index buffers to local-space OBJ triangles. */
(function(root) {
  "use strict";
  const types={5120:[1,"getInt8"],5121:[1,"getUint8"],5122:[2,"getInt16"],5123:[2,"getUint16"],5124:[4,"getInt32"],5125:[4,"getUint32"],5126:[4,"getFloat32"]};
  function read(view, offset, type, normalized) {
    const t=types[type]; if(!t || offset<0 || offset+t[0]>view.byteLength) throw Error("Buffer bounds");
    let v=view[t[1]](offset,true);
    if(normalized && type!==5126) { const bits=t[0]*8; v=type%2===0 ? Math.max(-1,v/(2**(bits-1)-1)) : v/(2**bits-1); }
    if(!Number.isFinite(v)) throw Error("Non-finite coordinate"); return v;
  }
  function obj(draws) {
    const out=["# 3D Capture: local-space triangle geometry; no materials, skinning or instance transforms."], warnings=[];
    let base=1, exported=0, totalIndices=0;
    for(const [di,d] of draws.entries()) {
      try {
        if(![4,5,6].includes(d.mode) || d.count<3) continue;
        if(!types[d.position.type] || d.position.size<2 || d.position.size>4) throw Error("Unsupported position format");
        if(d.count>500000 || totalIndices+d.count>500000) throw Error("Export exceeds 500,000 vertex references per frame; save originals for larger models");
        totalIndices+=d.count;
        const pv=new DataView(d.vertices.buffer,d.vertices.byteOffset,d.vertices.byteLength), p=d.position;
        const ids=[], map=new Map(), verts=[], faces=[];
        const iv=d.indices && new DataView(d.indices.buffer,d.indices.byteOffset,d.indices.byteLength);
        if(iv && ![5121,5123,5125].includes(d.indexType)) throw Error("Unsupported index format");
        const restart=d.indexType===5121 ? 255 : d.indexType===5123 ? 65535 : 4294967295;
        for(let i=0;i<d.count;i++) {
          const id=iv ? read(iv,d.offset+i*types[d.indexType][0],d.indexType,false) : d.first+i;
          if(iv && d.restart && id===restart) { ids.push(null); continue; }
          if(!map.has(id)) {
            const off=p.offset+id*(p.stride || p.size*types[p.type][0]);
            const v=[read(pv,off,p.type,p.normalized),read(pv,off+types[p.type][0],p.type,p.normalized),p.size>2 ? read(pv,off+2*types[p.type][0],p.type,p.normalized) : 0];
            map.set(id,base+verts.length); verts.push("v "+v.join(" "));
          }
          ids.push(map.get(id));
        }
        const face=(a,b,c)=>{if(a!=null&&b!=null&&c!=null&&a!==b&&b!==c&&a!==c)faces.push(`f ${a} ${b} ${c}`);};
        let segment=[];
        function flush() {
          if(d.mode===4) for(let i=0;i+2<segment.length;i+=3) face(segment[i],segment[i+1],segment[i+2]);
          if(d.mode===5) for(let i=2;i<segment.length;i++) i%2 ? face(segment[i-1],segment[i-2],segment[i]) : face(segment[i-2],segment[i-1],segment[i]);
          if(d.mode===6) for(let i=2;i<segment.length;i++) face(segment[0],segment[i-1],segment[i]);
          segment=[];
        }
        for(const id of ids) { if(id===null) flush(); else segment.push(id); } flush();
        if(!faces.length) continue;
        out.push("o mesh_"+(di+1)); for(const v of verts)out.push(v);for(const f of faces)out.push(f);base+=verts.length;exported++;
      } catch(e) { warnings.push(`Mesh ${di+1}: ${e.message}`); }
    }
    return {text:out.join("\n")+"\n",exported,warnings};
  }
  root.CaptureMesh={obj}; if(typeof module!=="undefined") module.exports=root.CaptureMesh;
})(globalThis);
