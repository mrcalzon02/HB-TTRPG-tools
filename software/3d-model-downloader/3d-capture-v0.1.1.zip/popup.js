"use strict";
let targetTab,latest,busy=false,lastSignature="";
const $=id=>document.getElementById(id);
const size=n=>n===0?"0 KB":n>=1048576?(n/1048576).toFixed(1)+" MB":Math.max(1,Math.round(n/1024))+" KB";
async function call(action,extra={}) {const r=await browser.runtime.sendMessage({action,tabId:targetTab,...extra});if(r?.error)throw Error(r.error);return r;}
async function task(fn) {
  if(busy)return;busy=true;$("error").textContent="";
  document.querySelectorAll("button").forEach(b=>b.disabled=true);
  try{await fn();await refresh();}catch(e){$("error").textContent=e.message;}finally{busy=false;document.querySelectorAll("button").forEach(b=>b.disabled=false);render();}
}
function render() {
  if(!latest)return;
  $("status").textContent=`${latest.active?"Recording":"Paused"} · ${latest.assets.length} files · ${size(latest.bytes)}${latest.pending?` · ${latest.pending} loading`:""}`;
  $("pause").disabled=busy||!latest.active;$("bundle").disabled=busy||!latest.assets.length;
  const selected=$("filter").value;
  const list=latest.assets.filter(a=>selected==="all" || (selected==="models"?!["texture","support"].includes(a.kind):a.kind===selected));
  const signature=JSON.stringify([selected,list.map(a=>[a.url,a.size])]);
  if(signature!==lastSignature) {
    lastSignature=signature;$("assets").replaceChildren();
    if(!list.length){const p=document.createElement("p");p.className="hint";p.textContent="No matching files yet. Start capture, then wait for the viewer to load.";$("assets").append(p);}
    for(const a of list) {
      const row=document.createElement("div");row.className="asset";
      const info=document.createElement("div"),name=document.createElement("strong"),meta=document.createElement("small"),button=document.createElement("button");
      name.textContent=a.path.split("/").pop();name.title=a.path;meta.textContent=a.kind.toUpperCase()+" · "+size(a.size)+" · "+new URL(a.url).host;button.textContent="Save";button.onclick=()=>task(()=>call("download",{url:a.url}));
      info.append(name,meta);row.append(info,button);$("assets").append(row);
    }
  }
  if(latest.warnings.length)$("error").textContent=latest.warnings.join("\n");
}
async function refresh() {if(targetTab===undefined)return;latest=await call("status");render();}
$("filter").onchange=render;
$("start").onclick=()=>task(()=>call("start"));$("pause").onclick=()=>task(()=>call("pause"));$("clear").onclick=()=>task(()=>call("clear"));
$("bundle").onclick=()=>task(()=>call("bundle"));$("mesh").onclick=()=>task(()=>call("mesh-export"));
$("expand").onclick=()=>browser.tabs.create({url:browser.runtime.getURL("popup.html")+"?tab="+targetTab});
(async()=>{
  const id=new URLSearchParams(location.search).get("tab");
  if(id!==null){targetTab=Number(id);document.body.classList.add("expanded");$("expand").hidden=true;}
  else {const tabs=await browser.tabs.query({active:true,currentWindow:true});targetTab=tabs[0]?.id;}
  if(!Number.isInteger(targetTab))throw Error("Open a viewer tab first.");
  const tab=await browser.tabs.get(targetTab);$("tabName").textContent=tab.title||tab.url;
  await refresh();
  const status=await call("mesh-status");
  const count=status.reduce((sum,r)=>sum+(r.data?.draws||0),0);$("meshInfo").textContent=count?`${count} recorded draw ranges across viewer frames.`:"Start capture and reload to record meshes.";
  setInterval(()=>{if(!busy)refresh().catch(e=>$("error").textContent=e.message);},1500);
})().catch(e=>$("error").textContent=e.message);
