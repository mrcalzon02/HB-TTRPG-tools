# 3D Capture for Firefox

A local Firefox extension for capturing original model files loaded by a viewer, with a WebGL geometry recovery fallback. Firefox 140 or newer is required.

## Permanent installation

The prepared 0.1.1 ZIP declares that the extension transmits no data. Standard Firefox requires a Mozilla-signed XPI for a permanent installation. Submit the ZIP to the Mozilla Add-ons Developer Hub using the **On your own** distribution option to obtain a signed copy without a public store listing. The unsigned ZIP itself cannot be installed permanently.

After signing, open **about:addons**, choose the gear menu, select **Install Add-on From File…**, and choose the signed XPI. This installation persists across browser restarts. Unlisted updates are installed manually unless an update service is configured. See SIGNING.md beside the source files for the remaining steps.

## Install

1. Open **about:debugging#/runtime/this-firefox** in Firefox.
2. Click **Load Temporary Add-on…**.
3. Select **manifest.json** in this folder, or select **3D-Capture-Firefox.zip** directly.
4. Return to the page containing your 3D viewer. Find **3D Capture** in Firefox's extensions menu (the puzzle-piece button); pin it to the toolbar if desired.

This development build is unsigned. Temporary installation lasts until Firefox closes. For a permanent installation, the extension needs Mozilla signing. Do not disable Firefox's signature checks.

## Capture your model

1. Open the extension from the viewer tab.
2. Click **Start capture & reload viewer**. This reloads the tab, so finish any unsaved work first.
3. Wait for the model to load. Rotate it, play any animation, or switch model variants to load additional geometry and textures.
4. Click **Save all as ZIP** under Original files. Extract the entire archive before opening a model. Use the Models only filter to find likely model files.
5. If the viewer does not deliver a usable original file, try **Export recorded meshes**. It saves a ZIP of OBJ files, one per supported viewer frame, plus export notes.

The arrow in the header opens a larger capture window linked to the same viewer tab. That window can stay open while you interact with the viewer. **Pause** stops recording and retains captured data. **Clear captured data** releases it; start capture and reload again to repopulate buffers.

## What it can recover

- Original responses for GLB, glTF, OBJ, FBX, STL, PLY, DAE and several other recognizable model formats.
- Textures and generic binary companion files. These may include unrelated resources from the selected page.
- Some model files served through opaque URLs, identified by their headers or signatures.
- WebGL 1 / WebGL 2 triangle, triangle-strip and triangle-fan geometry with recognizable position attributes, including indexed and interleaved positions. Standard indexed WebGL 2 primitive restart is handled.
- Matching HTTP/HTTPS embedded viewer frames in the selected tab.
- Local ZIP archives without external libraries or an online service. glTF buffer/image references are rewritten to matching captured archive paths. Missing glTF dependencies appear in capture.json. Other model formats are saved unchanged.

## Important limits

This is a recorder, not a general browser-memory dumper. An extension cannot enumerate every model already present in arbitrary JavaScript or GPU memory. Install it, start capture, and reload the viewer. Captured geometry is geometry observed during the recording session, rather than an exact inventory of objects still resident at export time. Existing GPU uploads that predate recording cannot be recovered reliably.

WebGL recovery saves **local-space positions and faces only**. It does not recover textures, UVs, materials, object/world transforms, instances, skeletons, animation, morph targets, or shader deformation. Separate objects may overlap when opened together. Dynamic buffers use their most recently captured contents. Prefer original files whenever possible.

WebGPU, OffscreenCanvas rendering in workers, GPU-generated geometry, packed/half-float positions, unrecognized shader attribute names, and unusual multi-draw extensions are unsupported by mesh recovery. A model that was not loaded or drawn may be missing. A service worker/cache can also prevent an original response from being observed. Protected Firefox pages cannot be recorded.

Partial HTTP 206 responses are skipped rather than mislabeled as complete files. HTTP errors and HTML login/error responses are excluded. This does not decrypt custom model formats or reconstruct a complete model from arbitrary range requests.

Capture limits: 128 MB per original response, 384 MB and 1,500 originals per tab; 32 MB per GPU buffer, 96 MB of GPU buffer copies and 1,000 observed draw ranges per frame; 500,000 vertex references / 32 MB OBJ per frame export. Capture can slow complex viewers. Export and clear periodically. Recording data is kept in extension memory and is lost on extension reload, browser exit, or closing the recorded tab.

## Privacy and permissions

There are no uploads, analytics, external scripts, or remote dependencies. Downloaded files are saved only when you choose an export. Broad site access and response-filtering permissions are needed to observe the selected tab's cross-origin asset requests. Other tabs are not recorded unless you start capture there.

The archive's capture.json contains original request URLs, which can include private signed query strings. Review it before sharing an archive. Page-world capture code can be detected or interfered with by the website. No browser or extension credentials are sent to it.

## Validation

Verified with Firefox 158 on Windows in a separate temporary profile: temporary installation, a viewer with a strict script policy, WebGL 2 indexed geometry export, response pass-through, MIME detection, opaque model/texture URLs, exclusion of partial and failed responses, pause retention, and clear. Automated checks also cover normalized positions, strips with restart indices, buffer bounds, tab isolation, ZIP CRCs, safe paths, and glTF companion reference rewriting. This has not been tested against your particular viewer yet.

To rerun the checks from this folder:

```text
node tests/unit.cjs
python tests/firefox_smoke.py
```

The Firefox smoke check uses Python's standard library, the installed Firefox at C:\Program Files\Mozilla Firefox\firefox.exe, and an isolated generated profile. It does not open or change your normal browser profile.

Mozilla references: [temporary installation](https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/), [response capture API](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/webRequest/filterResponseData), [page-world execution](https://blog.mozilla.org/addons/2024/07/10/manifest-v3-updates-landed-in-firefox-128/).
