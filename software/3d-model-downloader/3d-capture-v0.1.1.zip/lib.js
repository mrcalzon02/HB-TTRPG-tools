/* Pure asset detection, safe archive paths, and dependency-free ZIP writer. */
(function(root) {
  "use strict";
  const enc = new TextEncoder(), dec = new TextDecoder();
  function classify(url, mime = "", bytes = new Uint8Array()) {
    const path = new URL(url).pathname.toLowerCase();
    const text = dec.decode(bytes.subarray(0, 65536)).trimStart();
    if (/text\/html|application\/xhtml/i.test(mime) || /^<!doctype\s+html|^<html[\s>]/i.test(text)) return null;
    if (bytes.length >= 4 && dec.decode(bytes.subarray(0, 4)) === "glTF") return "glb";
    if (/^\s*\{/.test(text) && /"asset"\s*:/.test(text) && /"version"\s*:\s*"2/.test(text)) return "gltf";
    if (text.startsWith("Kaydara FBX Binary")) return "fbx";
    if (/^ply\r?\n/.test(text)) return "ply";
    if (/<COLLADA[\s>]/i.test(text)) return "dae";
    const model = path.match(/\.(glb|gltf|obj|fbx|stl|ply|dae|3ds|usdz?|abc|blend|3mf)$/);
    if (model) return model[1];
    if (/^model\//i.test(mime)) return "model";
    if (/^image\//i.test(mime) || /\.(png|jpe?g|webp|gif|avif|ktx2?|basis|dds|hdr|exr)$/.test(path)) return "texture";
    if (/\.(bin|drc|mesh|buffer|mtl)$/.test(path) || /octet-stream|gltf-buffer/i.test(mime)) return "support";
    if (/^#usda/.test(text)) return "usd";
    if (/^v\s+[-\d.]/m.test(text) && /^f\s+\d/m.test(text)) return "obj";
    return null;
  }
  function hash(s) { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return (h >>> 0).toString(16); }
  function safePart(s) {
    let value; try { value = decodeURIComponent(s); } catch { value = s; }
    value = value.replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").replace(/[. ]+$/g, "").slice(0, 100);
    if (!value || /^(con|prn|aux|nul|com\d|lpt\d)(\.|$)/i.test(value)) value = "_" + value;
    return value;
  }
  function assetPath(url, kind) {
    const u = new URL(url), parts = u.pathname.split("/").filter(Boolean).map(safePart);
    if (!parts.length) parts.push("asset");
    let name = parts.pop();
    if (u.search) { const dot = name.lastIndexOf("."); name = dot > 0 ? name.slice(0,dot)+"_"+hash(u.search)+name.slice(dot) : name+"_"+hash(u.search); }
    if (kind && !["texture","support","model"].includes(kind) && !/\.[a-z0-9]{1,5}$/i.test(name)) name += "."+kind;
    return ["assets",safePart(u.host),...parts,name].join("/");
  }
  function relative(from, to) {
    const a = from.split("/"); a.pop(); const b = to.split("/");
    while (a.length && b.length && a[0] === b[0]) { a.shift(); b.shift(); }
    return [...a.map(()=>".."),...b].map(p=>p === ".." ? p : encodeURIComponent(p)).join("/");
  }
  const crcTable = Array.from({length:256},(_,n)=>{ for(let i=0;i<8;i++) n = n&1 ? 0xedb88320 ^ (n>>>1) : n>>>1; return n>>>0; });
  function crc32(data) { let c=0xffffffff; for(const b of data) c=crcTable[(c^b)&255]^(c>>>8); return (c^0xffffffff)>>>0; }
  function zip(entries) {
    const local=[], central=[]; let offset=0, centralSize=0;
    if(entries.length>65535) throw Error("Too many files for ZIP.");
    for(const entry of entries) {
      const name=enc.encode(entry.name), data=typeof entry.data === "string" ? enc.encode(entry.data) : entry.data;
      const crc=crc32(data), head=new Uint8Array(30+name.length), h=new DataView(head.buffer);
      h.setUint32(0,0x04034b50,true); h.setUint16(4,20,true); h.setUint16(6,0x800,true);
      h.setUint16(12,33,true); h.setUint32(14,crc,true); h.setUint32(18,data.length,true); h.setUint32(22,data.length,true); h.setUint16(26,name.length,true); head.set(name,30);
      const cent=new Uint8Array(46+name.length), c=new DataView(cent.buffer);
      c.setUint32(0,0x02014b50,true); c.setUint16(4,20,true); c.setUint16(6,20,true); c.setUint16(8,0x800,true); c.setUint16(14,33,true);
      c.setUint32(16,crc,true); c.setUint32(20,data.length,true); c.setUint32(24,data.length,true); c.setUint16(28,name.length,true); c.setUint32(42,offset,true); cent.set(name,46);
      local.push(head,data); central.push(cent); offset+=head.length+data.length; centralSize+=cent.length;
    }
    const end=new Uint8Array(22), e=new DataView(end.buffer); e.setUint32(0,0x06054b50,true); e.setUint16(8,entries.length,true); e.setUint16(10,entries.length,true); e.setUint32(12,centralSize,true); e.setUint32(16,offset,true);
    return new Blob([...local,...central,end],{type:"application/zip"});
  }
  root.CaptureLib={classify,assetPath,relative,zip,crc32,hash};
  if(typeof module!=="undefined") module.exports=root.CaptureLib;
})(globalThis);
