/* Runs in the page world. Never receives extension privileges. */
(() => {
  "use strict";
  const CHANNEL="3d-capture-v1", marker="__3d_capture_recording";
  let active=false;
  try { active=sessionStorage.getItem(marker)==="1"; } catch {}
  let buffers=new WeakMap(), ids=new WeakMap(), programs=new WeakMap(), nextId=1, bytes=0;
  const draws=new Map(), warnings=new Set(), LIMIT=96*1024*1024;
  const id=o=>{if(!o)return 0;if(!ids.has(o))ids.set(o,nextId++);return ids.get(o);};
  const warn=s=>{if(warnings.size<30)warnings.add(s);};
  function bound(gl,target) {
    const binding={34962:34964,34963:34965,36662:36662,36663:36663,35051:35053,35052:35055,35345:35368,35982:35983}[target];
    return binding ? gl.getParameter(binding) : null;
  }
  function sourceBytes(source,offset=0,length) {
    if(source==null) return new Uint8Array();
    const step=source.BYTES_PER_ELEMENT || 1, start=offset*step;
    const view=ArrayBuffer.isView(source) ? new Uint8Array(source.buffer,source.byteOffset,source.byteLength) : new Uint8Array(source);
    return view.subarray(start,length===undefined || length===0 ? undefined : start+length*step);
  }
  function replace(buffer,data) {
    if(!buffer)return;
    const old=buffers.get(buffer); bytes-=old?.byteLength || 0; buffers.delete(buffer);
    if(data.byteLength>32*1024*1024 || bytes+data.byteLength>LIMIT) {warn("GPU buffer capture limit reached (32 MB per buffer / 96 MB per frame).");return;}
    const copy=data.slice(); buffers.set(buffer,copy); bytes+=copy.byteLength;
  }
  function attribute(gl,program) {
    if(programs.has(program))return programs.get(program);
    const count=gl.getProgramParameter(program,gl.ACTIVE_ATTRIBUTES), candidates=[];
    for(let i=0;i<count;i++) {
      const a=gl.getActiveAttrib(program,i); if(!a)continue;
      if(/(^|[_\W])(position|positions|pos|vertex|vertices)([_\W]|$)/i.test(a.name) || /position/i.test(a.name)) candidates.push({name:a.name,index:gl.getAttribLocation(program,a.name)});
    }
    const result=candidates.sort((a,b)=>(/position/i.test(b.name)?1:0)-(/position/i.test(a.name)?1:0))[0];
    programs.set(program,result); return result;
  }
  function record(gl,mode,count,indexType,offset,first=0,instances=1) {
    if(!active || ![4,5,6].includes(mode) || count<3 || instances===0)return;
    const program=gl.getParameter(gl.CURRENT_PROGRAM); if(!program)return;
    const a=attribute(gl,program); if(!a || a.index<0) {warn("Some shaders have no identifiable position attribute; their meshes are skipped.");return;}
    if(!gl.getVertexAttrib(a.index,gl.VERTEX_ATTRIB_ARRAY_ENABLED))return;
    if(gl.VERTEX_ATTRIB_ARRAY_DIVISOR && gl.getVertexAttrib(a.index,gl.VERTEX_ATTRIB_ARRAY_DIVISOR)>0) {warn("Instanced position attributes are unsupported.");return;}
    const vertexBuffer=gl.getVertexAttrib(a.index,gl.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING);
    const indexBuffer=indexType ? gl.getParameter(gl.ELEMENT_ARRAY_BUFFER_BINDING) : null;
    const position={size:gl.getVertexAttrib(a.index,gl.VERTEX_ATTRIB_ARRAY_SIZE),type:gl.getVertexAttrib(a.index,gl.VERTEX_ATTRIB_ARRAY_TYPE),normalized:gl.getVertexAttrib(a.index,gl.VERTEX_ATTRIB_ARRAY_NORMALIZED),stride:gl.getVertexAttrib(a.index,gl.VERTEX_ATTRIB_ARRAY_STRIDE),offset:gl.getVertexAttribOffset(a.index,gl.VERTEX_ATTRIB_ARRAY_POINTER)};
    const key=[id(gl),id(vertexBuffer),id(indexBuffer),mode,count,indexType,offset,first,JSON.stringify(position)].join(":");
    if(draws.size>=1000 && !draws.has(key)) {warn("Mesh limit reached (1,000 draw ranges per frame).");return;}
    draws.set(key,{vertexBuffer,indexBuffer,position,mode,count,indexType,offset,first,restart:typeof WebGL2RenderingContext!=="undefined" && gl instanceof WebGL2RenderingContext});
    if(instances>1)warn("Instanced meshes export one local-space copy; instance transforms are not recovered.");
  }
  function wrap(proto,name,after) {
    const original=proto?.[name]; if(typeof original!=="function" || original.__captureWrapped)return;
    const fn=function(...args) { const result=Reflect.apply(original,this,args); if(active)try{after.call(this,args,result);}catch(e){warn("Capture skipped an operation: "+e.message);}return result; };
    Object.defineProperty(fn,"__captureWrapped",{value:true});
    try { proto[name]=fn; } catch {}
  }
  for(const proto of [globalThis.WebGLRenderingContext?.prototype,globalThis.WebGL2RenderingContext?.prototype]) {
    wrap(proto,"bufferData",function(a){const buffer=bound(this,a[0]); if(typeof a[1]==="number") {if(a[1]<=32*1024*1024 && a[1]>=0)replace(buffer,new Uint8Array(a[1]));else warn("A GPU allocation exceeds the buffer limit.");} else replace(buffer,sourceBytes(a[1],a[3],a[4]));});
    wrap(proto,"bufferSubData",function(a){const data=buffers.get(bound(this,a[0]));if(!data)return;const src=sourceBytes(a[2],a[3],a[4]);if(a[1]>=0&&a[1]+src.length<=data.length)data.set(src,a[1]);});
    wrap(proto,"copyBufferSubData",function(a){const src=buffers.get(bound(this,a[0])),dst=buffers.get(bound(this,a[1]));if(src&&dst&&a[2]>=0&&a[3]>=0&&a[4]>=0&&a[2]+a[4]<=src.length&&a[3]+a[4]<=dst.length)dst.set(src.slice(a[2],a[2]+a[4]),a[3]);else {const b=bound(this,a[1]);bytes-=buffers.get(b)?.length||0;buffers.delete(b);warn("GPU-only buffer copies could not be recovered.");}});
    wrap(proto,"linkProgram",function(a){programs.delete(a[0]);});
    wrap(proto,"drawArrays",function(a){record(this,a[0],a[2],null,0,a[1]);});
    wrap(proto,"drawElements",function(a){record(this,a[0],a[1],a[2],a[3]);});
    wrap(proto,"drawArraysInstanced",function(a){record(this,a[0],a[2],null,0,a[1],a[3]);});
    wrap(proto,"drawElementsInstanced",function(a){record(this,a[0],a[1],a[2],a[3],0,a[4]);});
    wrap(proto,"drawRangeElements",function(a){record(this,a[0],a[3],a[4],a[5]);});
    wrap(proto,"getExtension",function(a,result){if(a[0]?.toLowerCase()==="angle_instanced_arrays" && result) { const gl=this;wrap(result,"drawArraysInstancedANGLE",function(v){record(gl,v[0],v[2],null,0,v[1],v[3]);});wrap(result,"drawElementsInstancedANGLE",function(v){record(gl,v[0],v[1],v[2],v[3],0,v[4]);}); }});
  }
  addEventListener("message",event=>{
    if(event.source!==window || event.data?.channel!==CHANNEL || event.data.direction!=="to-page")return;
    const {action,requestId}=event.data;
    if(action==="enable" || action==="disable" || action==="pause" || action==="clear") {
      if(action!=="clear") {active=action==="enable";try{active?sessionStorage.setItem(marker,"1"):sessionStorage.removeItem(marker);}catch{}}
      if(action==="disable" || action==="clear") {buffers=new WeakMap();draws.clear();bytes=0;warnings.clear();}
    }
    if(action==="status")postMessage({channel:CHANNEL,direction:"from-page",requestId,data:{draws:draws.size,bytes,warnings:[...warnings],active}},"*");
    if(action==="export") {
      const list=[];
      for(const d of draws.values()) {
        const vertices=buffers.get(d.vertexBuffer),indices=d.indexBuffer && buffers.get(d.indexBuffer);
        if(!vertices || (d.indexBuffer&&!indices)) {warn("Some buffers were uploaded before recording or exceeded capture limits.");continue;}
        list.push({...d,vertices,indices});
      }
      const result=CaptureMesh.obj(list);
      if(result.text.length>32*1024*1024) {result.text="";result.exported=0;result.warnings.push("OBJ exceeds the 32 MB per-frame export limit.");}
      postMessage({channel:CHANNEL,direction:"from-page",requestId,data:{...result,warnings:[...warnings,...result.warnings]}},"*");
    }
  });
})();
